import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const routes = [
  { path: '/login',           component: () => import('@/views/LoginView.vue'),          meta: { guest: true } },
  { path: '/register',        component: () => import('@/views/RegisterView.vue'),       meta: { guest: true } },
  { path: '/forgot-password', component: () => import('@/views/ForgotPasswordView.vue'), meta: { guest: true } },
  { path: '/reset-password/:token', component: () => import('@/views/ResetPasswordView.vue'), meta: { guest: true } },

  { path: '/',                redirect: '/chats' },
  { path: '/chats',           component: () => import('@/views/ChatsView.vue'),          meta: { auth: true } },
  { path: '/chat/:id',        component: () => import('@/views/ChatView.vue'),           meta: { auth: true } },
  { path: '/group/:id',       component: () => import('@/views/GroupChatView.vue'),      meta: { auth: true } },
  { path: '/group/:id/members', component: () => import('@/views/GroupMembersView.vue'), meta: { auth: true } },

  { path: '/profile/:id',     component: () => import('@/views/ProfileView.vue'),       meta: { auth: true } },
  { path: '/edit-profile',    component: () => import('@/views/EditProfileView.vue'),    meta: { auth: true } },

  { path: '/security',        component: () => import('@/views/SecurityView.vue'),       meta: { auth: true } },
  { path: '/security/password', component: () => import('@/views/PasswordView.vue'),    meta: { auth: true } },
  { path: '/security/devices',  component: () => import('@/views/DevicesView.vue'),     meta: { auth: true } },
  { path: '/security/blacklist', component: () => import('@/views/BlacklistView.vue'),  meta: { auth: true } },
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach(async (to) => {
  const auth = useAuthStore()
  if (!auth.user) await auth.fetchMe()

  if (to.meta.auth && !auth.user)  return '/login'
  if (to.meta.guest && auth.user)  return '/chats'
})

export default router
