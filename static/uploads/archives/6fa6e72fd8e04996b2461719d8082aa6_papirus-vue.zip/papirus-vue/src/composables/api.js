import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  withCredentials: true
})

api.interceptors.response.use(
  r => r,
  err => {
    if (err.response?.status === 401) {
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export default {
  // Auth
  login: (data) => api.post('/auth/login', data),
  register: (data) => api.post('/auth/register', data),
  logout: () => api.post('/auth/logout'),
  forgotPassword: (data) => api.post('/auth/forgot_password', data),
  resetPassword: (token, data) => api.post(`/auth/reset_password/${token}`, data),

  // User
  getMe: () => api.get('/users/me'),
  getUser: (id) => api.get(`/users/${id}`),
  updateProfile: (data) => api.post('/users/me/update', data),
  changePassword: (data) => api.post('/security/change_password', data),

  // Chats
  getChats: () => api.get('/chats'),
  createChat: (data) => api.post('/chats/create', data),
  deleteChat: (id) => api.delete(`/chats/${id}`),
  getChatMessages: (id, page = 1) => api.get(`/chats/${id}/messages?page=${page}`),
  sendMessage: (id, data) => api.post(`/chats/${id}/send`, data),
  editMessage: (msgId, data) => api.post(`/messages/${msgId}/edit`, data),
  deleteMessage: (msgId) => api.delete(`/messages/${msgId}`),
  forwardMessage: (msgId, data) => api.post(`/messages/${msgId}/forward`, data),

  // Groups
  getGroups: () => api.get('/groups'),
  createGroup: (data) => api.post('/groups/create', data),
  getGroup: (id) => api.get(`/groups/${id}`),
  getGroupMessages: (id, page = 1) => api.get(`/groups/${id}/messages?page=${page}`),
  sendGroupMessage: (id, data) => api.post(`/groups/${id}/send`, data),
  getGroupMembers: (id) => api.get(`/groups/${id}/members`),
  addGroupMember: (id, data) => api.post(`/groups/${id}/add_member`, data),
  removeGroupMember: (id, userId) => api.post(`/groups/${id}/remove_member`, { user_id: userId }),
  leaveGroup: (id) => api.post(`/groups/${id}/leave`),
  deleteGroup: (id) => api.delete(`/groups/${id}`),
  updateGroup: (id, data) => api.post(`/groups/${id}/update`, data),

  // Security
  getSessions: () => api.get('/security/sessions'),
  terminateSession: (id) => api.post(`/security/sessions/${id}/terminate`),
  terminateAllSessions: () => api.post('/security/sessions/terminate_all'),
  getBlockedUsers: () => api.get('/security/blocked'),
  blockUser: (id) => api.post(`/security/block/${id}`),
  unblockUser: (id) => api.post(`/security/unblock/${id}`),

  // Search users
  searchUsers: (q) => api.get(`/users/search?q=${encodeURIComponent(q)}`),
}
