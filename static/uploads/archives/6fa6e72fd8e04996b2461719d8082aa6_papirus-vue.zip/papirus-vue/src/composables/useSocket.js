import { io } from 'socket.io-client'
import { ref } from 'vue'

let socket = null
const connected = ref(false)

export function useSocket() {
  function connect() {
    if (socket?.connected) return socket
    socket = io('/', { withCredentials: true })
    socket.on('connect', () => { connected.value = true })
    socket.on('disconnect', () => { connected.value = false })
    return socket
  }

  function disconnect() {
    socket?.disconnect()
    socket = null
  }

  function getSocket() {
    return socket
  }

  return { connect, disconnect, getSocket, connected }
}
