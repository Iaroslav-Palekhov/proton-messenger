import { ref } from 'vue'

const toastText = ref('')
const toastVisible = ref(false)
let toastTimer = null

export function useToast() {
  function showToast(text) {
    toastText.value = text
    toastVisible.value = true
    if (toastTimer) clearTimeout(toastTimer)
    toastTimer = setTimeout(() => { toastVisible.value = false }, 2800)
  }
  return { toastText, toastVisible, showToast }
}
