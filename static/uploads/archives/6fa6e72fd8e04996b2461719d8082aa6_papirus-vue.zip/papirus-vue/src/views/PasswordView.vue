<template>
  <div class="security-page">
    <div class="security-card">
      <div class="security-header">
        <RouterLink to="/security" class="back-btn">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-back"/></svg>
        </RouterLink>
        <h1>Пароль</h1>
      </div>

      <div class="section" style="margin-top:20px">
        <div class="section-title">Смена пароля</div>
        <div class="section-card">
          <div class="password-form">
            <div v-if="message" :class="['pw-message', messageType]">{{ message }}</div>

            <div class="field-wrap">
              <label>Текущий пароль</label>
              <input :type="show.current ? 'text' : 'password'" v-model="form.current_password"
                     placeholder="Введите текущий пароль" autocomplete="current-password" />
              <button type="button" class="toggle-pw" @click="show.current = !show.current">
                <svg width="18" height="18" viewBox="0 0 24 24">
                  <use :href="show.current ? '#icon-eye-off' : '#icon-eye'" />
                </svg>
              </button>
            </div>

            <div class="field-wrap">
              <label>Новый пароль</label>
              <input :type="show.new ? 'text' : 'password'" v-model="form.new_password"
                     placeholder="Минимум 8 символов" @input="checkStrength" autocomplete="new-password" />
              <button type="button" class="toggle-pw" @click="show.new = !show.new">
                <svg width="18" height="18" viewBox="0 0 24 24">
                  <use :href="show.new ? '#icon-eye-off' : '#icon-eye'" />
                </svg>
              </button>
              <div class="strength-bar-4">
                <span v-for="i in 4" :key="i" :style="{ background: strengthColor(i) }"></span>
              </div>
              <div class="strength-label" :style="{ color: strengthColors[strengthScore - 1] }">
                {{ strengthLabels[strengthScore - 1] || '' }}
              </div>
            </div>

            <div class="field-wrap">
              <label>Повторите новый пароль</label>
              <input :type="show.confirm ? 'text' : 'password'" v-model="form.confirm_password"
                     placeholder="Повторите пароль" autocomplete="new-password" />
              <button type="button" class="toggle-pw" @click="show.confirm = !show.confirm">
                <svg width="18" height="18" viewBox="0 0 24 24">
                  <use :href="show.confirm ? '#icon-eye-off' : '#icon-eye'" />
                </svg>
              </button>
            </div>

            <button class="pw-save-btn" :disabled="saving" @click="changePassword">
              {{ saving ? 'Сохраняем...' : 'Сохранить пароль' }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import api from '@/composables/api'

const form = reactive({ current_password: '', new_password: '', confirm_password: '' })
const show = reactive({ current: false, new: false, confirm: false })
const saving = ref(false)
const message = ref('')
const messageType = ref('error')
const strengthScore = ref(0)
const strengthColors = ['#f87171', '#fb923c', '#facc15', '#4ade80']
const strengthLabels = ['Очень слабый', 'Слабый', 'Хороший', 'Надёжный']

function checkStrength() {
  const p = form.new_password
  let s = 0
  if (p.length >= 8) s++
  if (p.length >= 12) s++
  if (/[A-Z]/.test(p) && /[a-z]/.test(p)) s++
  if (/\d/.test(p) && /[^A-Za-z0-9]/.test(p)) s++
  strengthScore.value = s
}

function strengthColor(i) {
  return i <= strengthScore.value ? (strengthColors[strengthScore.value - 1] || 'var(--border)') : 'var(--border)'
}

function showMsg(text, type) {
  message.value = text
  messageType.value = type
  if (type === 'success') setTimeout(() => { message.value = '' }, 4000)
}

async function changePassword() {
  if (!form.current_password || !form.new_password || !form.confirm_password) {
    showMsg('Заполните все поля', 'error'); return
  }
  if (form.new_password !== form.confirm_password) {
    showMsg('Новые пароли не совпадают', 'error'); return
  }
  if (form.new_password.length < 8) {
    showMsg('Пароль должен быть минимум 8 символов', 'error'); return
  }
  saving.value = true
  try {
    await api.changePassword(form)
    showMsg('✓ Пароль успешно изменён', 'success')
    form.current_password = ''
    form.new_password = ''
    form.confirm_password = ''
    strengthScore.value = 0
  } catch (e) {
    showMsg(e.response?.data?.error || 'Ошибка при смене пароля', 'error')
  } finally {
    saving.value = false
  }
}
</script>

<style scoped>
.password-form { padding: 16px; display: flex; flex-direction: column; gap: 14px; }
.field-wrap { position: relative; }
.field-wrap label { display: block; font-size: 12px; color: var(--text-muted); margin-bottom: 6px; font-weight: 600; }
.field-wrap input {
  width: 100%; padding: 13px 44px 13px 14px;
  background: var(--bg-secondary); border: 1.5px solid var(--border);
  border-radius: 12px; color: var(--text-primary); font-size: 15px;
  box-sizing: border-box; transition: border-color .2s; font-family: inherit; outline: none;
}
.field-wrap input:focus { border-color: var(--accent); }
.toggle-pw {
  position: absolute; right: 12px; bottom: 13px;
  cursor: pointer; color: var(--text-muted); background: none; border: none; padding: 0; line-height: 1;
}
.strength-bar-4 { display: flex; gap: 4px; margin-top: 6px; }
.strength-bar-4 span { flex: 1; height: 3px; border-radius: 2px; transition: background .3s; }
.strength-label { font-size: 11px; margin-top: 4px; min-height: 16px; }
.pw-save-btn {
  width: 100%; padding: 14px; background: var(--accent); color: white;
  border: none; border-radius: 12px; font-size: 15px; font-weight: 600;
  cursor: pointer; transition: opacity .2s, transform .15s; font-family: inherit;
}
.pw-save-btn:hover { opacity: .88; }
.pw-save-btn:active { transform: scale(0.97); }
.pw-save-btn:disabled { opacity: .5; cursor: not-allowed; }
.pw-message {
  padding: 10px 14px; border-radius: 10px; font-size: 14px; font-weight: 500;
}
.pw-message.error   { background: rgba(239,68,68,.15); color: #f87171; }
.pw-message.success { background: rgba(34,197,94,.15);  color: #4ade80; }
</style>
