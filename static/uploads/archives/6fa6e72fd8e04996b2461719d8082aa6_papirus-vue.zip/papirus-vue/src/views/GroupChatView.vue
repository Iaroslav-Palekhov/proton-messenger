<template>
  <div class="chat-container">
    <!-- Header -->
    <div class="chat-header">
      <div class="chat-user-info">
        <RouterLink to="/chats" class="btn-icon" style="margin-right:4px">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-back"/></svg>
        </RouterLink>
        <div class="chat-avatar-wrap">
          <img :src="groupIconUrl(group?.icon)" class="chat-avatar-img" @error="onImgError" />
        </div>
        <div class="chat-user-details">
          <h2>{{ group?.name || '...' }}</h2>
          <p>{{ group?.member_count || 0 }} участников</p>
        </div>
      </div>
      <div class="header-actions">
        <RouterLink :to="`/group/${groupId}/members`" class="btn-icon" title="Участники">
          <svg width="20" height="20" viewBox="0 0 24 24"><use href="#icon-group"/></svg>
        </RouterLink>
        <button v-if="isOwner" class="btn-icon" @click="showEditModal = true" title="Настройки">
          <svg width="20" height="20" viewBox="0 0 24 24"><use href="#icon-edit"/></svg>
        </button>
      </div>
    </div>

    <!-- Reply bar -->
    <Transition name="slide-down">
      <div v-if="replyTo || editMsg" class="reply-bar">
        <div class="reply-bar-inner">
          <div class="reply-line"></div>
          <div class="reply-info">
            <span class="reply-label">{{ editMsg ? 'Редактирование' : `Ответ: ${replyTo?.sender?.username}` }}</span>
            <span class="reply-text">{{ editMsg?.content || replyTo?.content }}</span>
          </div>
        </div>
        <button class="reply-close" @click="clearReply">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-close"/></svg>
        </button>
      </div>
    </Transition>

    <!-- Messages -->
    <div class="messages-container" ref="msgsEl" @scroll="onScroll">
      <div v-if="loadingMore" style="text-align:center;padding:10px;color:var(--text-muted);font-size:13px">Загрузка...</div>
      <div v-for="msg in messages" :key="msg.id"
           class="message" :class="msg.sender_id === auth.user?.id ? 'sent' : 'received'"
           :id="`msg-${msg.id}`"
           @contextmenu.prevent="showCtxMenu($event, msg)">
        <div class="message-wrapper">
          <img v-if="msg.sender_id !== auth.user?.id"
               :src="avatarUrl(msg.sender?.avatar)"
               class="message-avatar"
               @click="$router.push(`/profile/${msg.sender_id}`)" />
          <div class="message-bubble">
            <!-- Sender name for received messages -->
            <div v-if="msg.sender_id !== auth.user?.id" class="group-sender-name"
                 @click="$router.push(`/profile/${msg.sender_id}`)">
              {{ msg.sender?.username }}
            </div>

            <div v-if="msg.reply_to" class="reply-preview" @click="scrollToMsg(msg.reply_to_id)">
              <div class="reply-preview-line"></div>
              <div>
                <div class="reply-preview-author">{{ msg.reply_to.sender?.username }}</div>
                <div class="reply-preview-text">{{ msg.reply_to.content?.slice(0,60) }}</div>
              </div>
            </div>

            <div v-if="msg.is_forwarded" class="forwarded-label">
              <svg width="12" height="12" viewBox="0 0 24 24"><use href="#icon-forward"/></svg>
              Переслано
            </div>

            <img v-if="msg.image_path" :src="`/static/uploads/${msg.image_path}`"
                 class="message-image" @click="lightboxSrc = `/static/uploads/${msg.image_path}`" />

            <a v-if="msg.file_path && !msg.image_path" :href="`/static/uploads/${msg.file_path}`"
               class="file-message" target="_blank">
              <span class="file-icon">{{ fileIcon(msg.file_name) }}</span>
              <div class="file-info">
                <div class="file-name">{{ msg.file_name }}</div>
                <div class="file-size">{{ formatSize(msg.file_size) }}</div>
              </div>
              <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-download"/></svg>
            </a>

            <div v-if="msg.content && !msg.is_deleted" class="message-content">
              <p>{{ msg.content }}</p>
            </div>
            <div v-if="msg.is_deleted" class="message-content" style="color:var(--text-muted);font-style:italic">
              <p>Сообщение удалено</p>
            </div>

            <div class="message-meta">
              <span v-if="msg.is_edited && !msg.is_deleted" style="font-size:10px;opacity:.7">изм.</span>
              <span v-if="msg.is_pinned"><svg width="10" height="10" viewBox="0 0 24 24"><use href="#icon-pin"/></svg></span>
              <span>{{ formatTime(msg.timestamp) }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Input -->
    <div class="message-input">
      <div v-if="filePreview" class="file-preview">
        <div class="file-preview-info">
          <span class="file-icon">{{ fileIcon(filePreview.name) }}</span>
          <span>{{ filePreview.name }}</span>
        </div>
        <span class="file-preview-remove" @click="filePreview = null">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-close"/></svg>
        </span>
      </div>
      <div class="input-group">
        <label class="btn-icon" style="cursor:pointer">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-attach"/></svg>
          <input type="file" style="display:none" @change="onFileChange" />
        </label>
        <input v-model="inputText" type="text" placeholder="Сообщение..."
               @keyup.enter="sendMessage" />
        <button class="btn-icon send-btn" @click="sendMessage">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-send"/></svg>
        </button>
      </div>
    </div>

    <!-- Context menu -->
    <Teleport to="body">
      <div v-if="ctxMenu.show" class="context-menu"
           :style="{ top: ctxMenu.y + 'px', left: ctxMenu.x + 'px' }" @click.stop>
        <div class="context-menu-item" @click="replyToMsg(ctxMenu.msg)">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-reply"/></svg> Ответить
        </div>
        <div v-if="ctxMenu.msg?.sender_id === auth.user?.id" class="context-menu-item" @click="startEdit(ctxMenu.msg)">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-edit"/></svg> Редактировать
        </div>
        <div class="context-menu-item" @click="copyMsg(ctxMenu.msg)">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-copy"/></svg> Копировать
        </div>
        <div v-if="isOwner || ctxMenu.msg?.sender_id === auth.user?.id" class="context-menu-item" @click="pinMsg(ctxMenu.msg)">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-pin"/></svg>
          {{ ctxMenu.msg?.is_pinned ? 'Открепить' : 'Закрепить' }}
        </div>
        <div class="context-menu-divider"></div>
        <div v-if="ctxMenu.msg?.sender_id === auth.user?.id || isOwner" class="context-menu-item delete-item" @click="deleteMsg(ctxMenu.msg)">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-delete"/></svg> Удалить
        </div>
      </div>
    </Teleport>

    <!-- Edit group modal -->
    <Teleport to="body">
      <div v-if="showEditModal" class="modal-overlay" @click.self="showEditModal = false">
        <div class="modal-content">
          <div class="modal-header">
            <h2>Настройки группы</h2>
            <button class="close-modal" @click="showEditModal = false">×</button>
          </div>
          <div class="form-group">
            <label>Название</label>
            <input v-model="editGroupForm.name" type="text" />
          </div>
          <div class="form-group">
            <label>Описание</label>
            <textarea v-model="editGroupForm.description"></textarea>
          </div>
          <div class="modal-actions">
            <button class="btn" @click="saveGroup">Сохранить</button>
            <button class="btn btn-danger" @click="deleteGroup">Удалить группу</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Lightbox -->
    <Teleport to="body">
      <div v-if="lightboxSrc" class="modal-overlay" @click="lightboxSrc = null" style="background:rgba(0,0,0,.95)">
        <img :src="lightboxSrc" style="max-width:90vw;max-height:90vh;border-radius:8px" />
      </div>
    </Teleport>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useSocket } from '@/composables/useSocket'
import { useToast } from '@/composables/useToast'
import api from '@/composables/api'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const { connect, getSocket } = useSocket()
const { showToast } = useToast()

const groupId = computed(() => route.params.id)
const group = ref(null)
const messages = ref([])
const inputText = ref('')
const msgsEl = ref(null)
const loadingMore = ref(false)
const page = ref(1)
const hasMore = ref(true)
const filePreview = ref(null)
const replyTo = ref(null)
const editMsg = ref(null)
const lightboxSrc = ref(null)
const showEditModal = ref(false)
const editGroupForm = ref({ name: '', description: '' })
const ctxMenu = ref({ show: false, x: 0, y: 0, msg: null })

const isOwner = computed(() => group.value?.owner_id === auth.user?.id)

function avatarUrl(p) { return p ? `/static/uploads/${p}` : '/static/uploads/avatars/default.png' }
function groupIconUrl(p) { return p ? `/static/uploads/${p}` : '/static/uploads/group_icons/default.png' }
function onImgError(e) { e.target.src = '/static/uploads/group_icons/default.png' }
function formatTime(ts) {
  if (!ts) return ''
  return new Date(ts).toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' })
}
function formatSize(b) {
  if (!b) return ''
  if (b < 1024) return b + ' B'
  if (b < 1048576) return (b/1024).toFixed(1) + ' KB'
  return (b/1048576).toFixed(1) + ' MB'
}
function fileIcon(name) {
  const ext = name?.split('.').pop()?.toLowerCase() || ''
  const m = {jpg:'🖼️',jpeg:'🖼️',png:'🖼️',gif:'🎨',mp4:'🎬',mp3:'🎵',wav:'🎵',pdf:'📄',doc:'📝',docx:'📝',txt:'📄',zip:'📦',rar:'📦'}
  return m[ext] || '📎'
}

function scrollToBottom() {
  nextTick(() => { if (msgsEl.value) msgsEl.value.scrollTop = msgsEl.value.scrollHeight })
}

function scrollToMsg(id) {
  const el = document.getElementById(`msg-${id}`)
  if (el) { el.scrollIntoView({ behavior: 'smooth' }); el.style.outline = '2px solid var(--accent)'; setTimeout(() => el.style.outline = '', 1500) }
}

async function load(p = 1) {
  const res = await api.getGroupMessages(groupId.value, p)
  const data = res.data
  group.value = data.group
  editGroupForm.value = { name: data.group?.name || '', description: data.group?.description || '' }
  if (p === 1) {
    messages.value = data.messages || []
    scrollToBottom()
  } else {
    messages.value = [...(data.messages || []), ...messages.value]
  }
  hasMore.value = data.has_more
}

function onScroll() {
  if (msgsEl.value?.scrollTop < 50 && hasMore.value && !loadingMore.value) {
    loadingMore.value = true
    page.value++
    const prevH = msgsEl.value.scrollHeight
    load(page.value).then(() => nextTick(() => { msgsEl.value.scrollTop = msgsEl.value.scrollHeight - prevH; loadingMore.value = false }))
  }
}

async function sendMessage() {
  const text = inputText.value.trim()
  if (!text && !filePreview.value) return
  const formData = new FormData()
  if (text) formData.append('content', text)
  if (replyTo.value) formData.append('reply_to_id', replyTo.value.id)
  if (filePreview.value) formData.append('file', filePreview.value.raw)
  try {
    if (editMsg.value) {
      await api.editMessage(editMsg.value.id, { content: text })
      const idx = messages.value.findIndex(m => m.id === editMsg.value.id)
      if (idx >= 0) messages.value[idx] = { ...messages.value[idx], content: text, is_edited: true }
      editMsg.value = null
    } else {
      const res = await api.sendGroupMessage(groupId.value, formData)
      messages.value.push(res.data.message)
      scrollToBottom()
    }
    inputText.value = ''
    filePreview.value = null
    replyTo.value = null
  } catch (e) { showToast(e.response?.data?.error || 'Ошибка') }
}

function onFileChange(e) {
  const f = e.target.files[0]
  if (f) filePreview.value = { name: f.name, raw: f }
}

function replyToMsg(msg) { replyTo.value = msg; editMsg.value = null; closeCtx() }
function startEdit(msg) { editMsg.value = msg; inputText.value = msg.content; replyTo.value = null; closeCtx() }
function clearReply() { replyTo.value = null; editMsg.value = null; inputText.value = '' }

async function deleteMsg(msg) {
  closeCtx()
  if (!confirm('Удалить сообщение?')) return
  try {
    await api.deleteMessage(msg.id)
    const idx = messages.value.findIndex(m => m.id === msg.id)
    if (idx >= 0) messages.value[idx] = { ...messages.value[idx], is_deleted: true }
  } catch { showToast('Ошибка') }
}

async function copyMsg(msg) { closeCtx(); await navigator.clipboard.writeText(msg.content || ''); showToast('Скопировано') }

async function pinMsg(msg) {
  closeCtx()
  showToast(msg.is_pinned ? 'Сообщение откреплено' : 'Сообщение закреплено')
}

async function saveGroup() {
  try {
    await api.updateGroup(groupId.value, editGroupForm.value)
    group.value = { ...group.value, ...editGroupForm.value }
    showEditModal.value = false
    showToast('Группа обновлена')
  } catch { showToast('Ошибка') }
}

async function deleteGroup() {
  if (!confirm('Удалить группу?')) return
  try {
    await api.deleteGroup(groupId.value)
    router.push('/chats')
  } catch { showToast('Ошибка') }
}

function showCtxMenu(e, msg) {
  ctxMenu.value = { show: true, x: Math.min(e.clientX, window.innerWidth - 220), y: Math.min(e.clientY, window.innerHeight - 200), msg }
}
function closeCtx() { ctxMenu.value.show = false }

onMounted(async () => {
  await load()
  const socket = connect()
  socket.emit('join_group', { group_id: groupId.value })
  socket.on('new_group_message', (msg) => {
    if (msg.group_id == groupId.value) { messages.value.push(msg); scrollToBottom() }
  })
  socket.on('message_edited', (data) => {
    const idx = messages.value.findIndex(m => m.id === data.message_id)
    if (idx >= 0) messages.value[idx] = { ...messages.value[idx], content: data.content, is_edited: true }
  })
  socket.on('message_deleted', (data) => {
    const idx = messages.value.findIndex(m => m.id === data.message_id)
    if (idx >= 0) messages.value[idx] = { ...messages.value[idx], is_deleted: true }
  })
  document.addEventListener('click', closeCtx)
})
onUnmounted(() => document.removeEventListener('click', closeCtx))
</script>

<style scoped>
.chat-container {
  display: flex; flex-direction: column; height: 100dvh;
  background: var(--bg-primary); overflow: hidden; position: fixed; inset: 0;
}
.chat-header {
  padding: 12px 16px; background: var(--bg-secondary);
  display: flex; justify-content: space-between; align-items: center;
  border-bottom: 1px solid var(--border); flex-shrink: 0;
}
.chat-user-info { display: flex; align-items: center; gap: 10px; }
.chat-avatar-img { width: 42px; height: 42px; border-radius: 50%; object-fit: cover; border: 2px solid var(--accent); }
.chat-user-details h2 { font-size: 17px; font-weight: 600; margin-bottom: 2px; }
.chat-user-details p { font-size: 13px; color: var(--text-secondary); }
.header-actions { display: flex; gap: 8px; }

.reply-bar {
  padding: 8px 16px; background: var(--bg-secondary);
  border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 10px; flex-shrink: 0;
}
.reply-bar-inner { display: flex; align-items: center; gap: 10px; flex: 1; }
.reply-line { width: 3px; height: 36px; background: var(--accent); border-radius: 2px; flex-shrink: 0; }
.reply-label { font-size: 12px; color: var(--accent); font-weight: 600; }
.reply-text { font-size: 13px; color: var(--text-secondary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 250px; }
.reply-close { background: none; border: none; color: var(--text-muted); cursor: pointer; display: flex; align-items: center; }

.messages-container {
  flex: 1; min-height: 0; padding: 16px; overflow-y: auto;
  background: #0e1c26;
  background-image: radial-gradient(circle at 10% 20%, rgba(0,168,132,.03) 0%, transparent 20%);
  display: flex; flex-direction: column; gap: 6px;
}

.message { max-width: 65%; animation: messageAppear .2s ease-out; }
.message.sent { align-self: flex-end; }
.message.received { align-self: flex-start; }
.message-wrapper { display: flex; align-items: flex-end; gap: 8px; }
.message.sent .message-wrapper { flex-direction: row-reverse; }
.message-avatar { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; cursor: pointer; flex-shrink: 0; }

.message-bubble {
  padding: 10px 14px; border-radius: 18px;
  word-wrap: break-word; overflow-wrap: break-word;
}
.message.sent .message-bubble { background: var(--sent-message); border-bottom-right-radius: 4px; }
.message.received .message-bubble { background: var(--received-message); border-bottom-left-radius: 4px; }

.group-sender-name { font-size: 13px; font-weight: 600; color: var(--accent); margin-bottom: 4px; cursor: pointer; }

.message-content { margin-bottom: 4px; }
.message-content p { margin: 0; white-space: pre-wrap; line-height: 1.5; }
.message-image { max-width: 280px; max-height: 280px; border-radius: 12px; cursor: pointer; display: block; margin-bottom: 6px; }
.file-message { display: flex; align-items: center; gap: 10px; padding: 10px; background: rgba(255,255,255,.08); border-radius: 12px; text-decoration: none; color: var(--text-primary); min-width: 220px; }
.file-icon { font-size: 28px; }
.file-info { flex: 1; min-width: 0; }
.file-name { font-weight: 600; font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.file-size { font-size: 11px; color: var(--text-muted); }
.message-meta { display: flex; justify-content: flex-end; align-items: center; gap: 4px; font-size: 11px; margin-top: 4px; }
.message.sent .message-meta { color: rgba(255,255,255,.65); }
.message.received .message-meta { color: var(--text-muted); }
.forwarded-label { font-size: 12px; color: var(--text-secondary); margin-bottom: 6px; display: flex; align-items: center; gap: 4px; font-style: italic; }
.reply-preview { display: flex; gap: 8px; margin-bottom: 8px; cursor: pointer; background: rgba(255,255,255,.05); border-radius: 8px; padding: 6px 8px; }
.reply-preview-line { width: 3px; background: var(--accent); border-radius: 2px; flex-shrink: 0; }
.reply-preview-author { font-size: 12px; color: var(--accent); font-weight: 600; }
.reply-preview-text { font-size: 12px; color: var(--text-secondary); }

.message-input { padding: 16px; background: var(--bg-secondary); border-top: 1px solid var(--border); flex-shrink: 0; }
.file-preview { margin-bottom: 10px; padding: 10px 14px; background: var(--bg-tertiary); border-radius: var(--radius-md); display: flex; justify-content: space-between; align-items: center; }
.file-preview-info { display: flex; align-items: center; gap: 10px; font-size: 14px; }
.file-preview-remove { color: var(--danger); cursor: pointer; display: flex; align-items: center; }
.input-group { display: flex; gap: 10px; align-items: center; background: var(--bg-tertiary); border-radius: 24px; padding: 6px 10px; }
.input-group input { flex: 1; padding: 10px; background: transparent; border: none; color: var(--text-primary); font-size: 15px; outline: none; }
.input-group input::placeholder { color: var(--text-muted); }
.send-btn { background: var(--accent) !important; color: white !important; }
.send-btn:hover { background: var(--accent-hover) !important; }

.slide-down-enter-active, .slide-down-leave-active { transition: all 0.2s ease; }
.slide-down-enter-from, .slide-down-leave-to { opacity: 0; transform: translateY(-10px); }

@media (max-width: 768px) { .message { max-width: 85%; } }
</style>
