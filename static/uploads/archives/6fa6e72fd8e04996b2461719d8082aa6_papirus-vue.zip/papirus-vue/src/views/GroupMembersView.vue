<template>
  <div class="security-page">
    <div class="security-card">
      <div class="security-header">
        <RouterLink :to="`/group/${groupId}`" class="back-btn">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-back"/></svg>
        </RouterLink>
        <h1>Участники</h1>
      </div>

      <!-- Group info -->
      <div v-if="group" style="padding:20px 16px;display:flex;align-items:center;gap:16px;border-bottom:1px solid var(--border)">
        <img :src="groupIconUrl(group.icon)" style="width:60px;height:60px;border-radius:50%;object-fit:cover;border:2px solid var(--accent)" />
        <div>
          <div style="font-size:18px;font-weight:700">{{ group.name }}</div>
          <div style="font-size:13px;color:var(--text-secondary);margin-top:4px">{{ group.description }}</div>
        </div>
      </div>

      <!-- Add member -->
      <div v-if="isOwner" class="section" style="padding-top:16px">
        <div class="section-title">Добавить участника</div>
        <div class="section-card">
          <div style="padding:12px 16px;display:flex;gap:10px">
            <input v-model="addUsername" type="text" placeholder="Имя пользователя"
                   style="flex:1;padding:12px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:10px;color:var(--text-primary);font-size:14px;outline:none"
                   @keyup.enter="addMember" />
            <button class="btn btn-sm" @click="addMember">Добавить</button>
          </div>
          <div v-if="addError" style="padding:0 16px 12px;color:var(--danger);font-size:13px">{{ addError }}</div>
        </div>
      </div>

      <!-- Members list -->
      <div class="section" style="padding-top:16px">
        <div class="section-title">{{ members.length }} участников</div>
        <div class="section-card">
          <div v-for="(m, i) in members" :key="m.user_id" class="member-item"
               :style="i < members.length - 1 ? 'border-bottom:1px solid var(--border)' : ''">
            <RouterLink :to="`/profile/${m.user_id}`">
              <img :src="avatarUrl(m.avatar)" class="member-avatar" />
            </RouterLink>
            <div class="member-info">
              <div class="member-name">{{ m.username }}</div>
              <div class="member-role" :class="m.role">{{ roleLabel(m.role) }}</div>
            </div>
            <div v-if="isOwner && m.user_id !== auth.user?.id" class="member-actions">
              <button class="btn-icon btn-sm" style="width:32px;height:32px;color:var(--danger)"
                      @click="removeMember(m)" title="Удалить">
                <svg width="16" height="16" viewBox="0 0 24 24"><use href="#icon-delete"/></svg>
              </button>
            </div>
            <div v-if="m.user_id === auth.user?.id" style="font-size:12px;color:var(--text-muted)">Вы</div>
          </div>
        </div>
      </div>

      <!-- Leave group -->
      <div class="section" style="padding:20px 16px">
        <button class="btn btn-danger btn-block" @click="leaveGroup">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-logout"/></svg>
          Покинуть группу
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useToast } from '@/composables/useToast'
import api from '@/composables/api'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const { showToast } = useToast()

const groupId = computed(() => route.params.id)
const group = ref(null)
const members = ref([])
const addUsername = ref('')
const addError = ref('')
const isOwner = computed(() => group.value?.owner_id === auth.user?.id)

function avatarUrl(p) { return p ? `/static/uploads/${p}` : '/static/uploads/avatars/default.png' }
function groupIconUrl(p) { return p ? `/static/uploads/${p}` : '/static/uploads/group_icons/default.png' }
function roleLabel(role) { return role === 'owner' ? 'Владелец' : role === 'admin' ? 'Администратор' : 'Участник' }

async function load() {
  const res = await api.getGroupMembers(groupId.value)
  group.value = res.data.group
  members.value = res.data.members || []
}

async function addMember() {
  addError.value = ''
  if (!addUsername.value.trim()) { addError.value = 'Введите имя пользователя'; return }
  try {
    await api.addGroupMember(groupId.value, { username: addUsername.value.trim() })
    addUsername.value = ''
    showToast('Участник добавлен')
    load()
  } catch (e) { addError.value = e.response?.data?.error || 'Пользователь не найден' }
}

async function removeMember(m) {
  if (!confirm(`Удалить ${m.username} из группы?`)) return
  try {
    await api.removeGroupMember(groupId.value, m.user_id)
    members.value = members.value.filter(x => x.user_id !== m.user_id)
    showToast('Участник удалён')
  } catch { showToast('Ошибка') }
}

async function leaveGroup() {
  if (!confirm('Покинуть группу?')) return
  try {
    await api.leaveGroup(groupId.value)
    router.push('/chats')
  } catch { showToast('Ошибка') }
}

onMounted(load)
</script>

<style scoped>
.member-item {
  display: flex; align-items: center; gap: 12px; padding: 12px 16px; transition: background .15s;
}
.member-item:hover { background: rgba(255,255,255,.03); }
.member-avatar { width: 44px; height: 44px; border-radius: 50%; object-fit: cover; }
.member-info { flex: 1; }
.member-name { font-weight: 600; font-size: 15px; margin-bottom: 3px; }
.member-role { font-size: 12px; color: var(--accent); background: rgba(0,168,132,.1); padding: 2px 8px; border-radius: 12px; display: inline-block; }
.member-role.owner { background: rgba(255,193,7,.1); color: #ffc107; }
.member-actions { display: flex; gap: 6px; }
</style>
