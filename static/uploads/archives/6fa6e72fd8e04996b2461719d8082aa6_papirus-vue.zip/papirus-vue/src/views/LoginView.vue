<template>
  <div class="auth-wrapper">
    <div class="auth-container">
      <div class="logo">
        <div class="logo-icon">
          <svg width="44" height="44" viewBox="0 0 24 24"><use href="#icon-chat"/></svg>
        </div>
        <h1>Papirus</h1>
      </div>

      <div v-if="error" class="error-message">{{ error }}</div>
      <div v-if="success" class="success-message">{{ success }}</div>

      <div class="form-group">
        <label>Email или имя пользователя</label>
        <input v-model="form.username" type="text" placeholder="Введите email или username"
               @keyup.enter="submit" autocomplete="username" />
      </div>

      <div class="form-group">
        <label>Пароль</label>
        <div style="position:relative">
          <input v-model="form.password" :type="showPw ? 'text' : 'password'"
                 placeholder="Введите пароль" @keyup.enter="submit"
                 autocomplete="current-password" style="padding-right:48px" />
          <button type="button" class="pw-toggle" @click="showPw = !showPw">
            <svg width="18" height="18" viewBox="0 0 24 24">
              <use :href="showPw ? '#icon-eye-off' : '#icon-eye'" />
            </svg>
          </button>
        </div>
      </div>

      <button class="btn btn-block" :disabled="loading" @click="submit">
        <span v-if="loading">Вход...</span>
        <span v-else>Войти</span>
      </button>

      <div class="auth-links" style="margin-top:15px;text-align:center">
        <div style="margin-bottom:10px">
          <RouterLink to="/forgot-password" style="color:var(--accent);text-decoration:none;font-size:14px">
            Забыли пароль?
          </RouterLink>
        </div>
        <div class="auth-link">
          Нет аккаунта? <RouterLink to="/register">Создать аккаунт</RouterLink>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import api from '@/composables/api'

const router = useRouter()
const auth = useAuthStore()

const form = ref({ username: '', password: '' })
const error = ref('')
const success = ref(router.currentRoute.value.query.success || '')
const loading = ref(false)
const showPw = ref(false)

async function submit() {
  error.value = ''
  if (!form.value.username || !form.value.password) {
    error.value = 'Заполните все поля'
    return
  }
  loading.value = true
  try {
    await api.login(form.value)
    await auth.fetchMe()
    router.push('/chats')
  } catch (e) {
    error.value = e.response?.data?.error || 'Неверный логин или пароль'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.pw-toggle {
  position: absolute;
  right: 14px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  color: var(--text-muted);
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
}
.pw-toggle:hover { color: var(--text-secondary); }
</style>
