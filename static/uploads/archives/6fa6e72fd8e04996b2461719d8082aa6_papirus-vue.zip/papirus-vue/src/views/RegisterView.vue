<template>
  <div class="auth-wrapper">
    <div class="auth-container">
      <div class="logo">
        <div class="logo-icon">
          <svg width="44" height="44" viewBox="0 0 24 24"><use href="#icon-profile"/></svg>
        </div>
        <h1>Создать аккаунт</h1>
      </div>

      <div v-if="error" class="error-message">{{ error }}</div>

      <div class="form-group">
        <label>Имя пользователя</label>
        <input v-model="form.username" :class="usernameClass" type="text"
               placeholder="Минимум 5 символов" @input="validateUsername" autocomplete="username" />
        <div class="field-hint" :class="usernameHintClass">{{ usernameHint }}</div>
      </div>

      <div class="form-group">
        <label>Email</label>
        <input v-model="form.email" :class="emailClass" type="email"
               placeholder="example@email.com" @input="validateEmail" autocomplete="email" />
        <div class="field-hint" :class="emailHintClass">{{ emailHint }}</div>
      </div>

      <div class="form-group">
        <label>Пароль</label>
        <input v-model="form.password" type="password" placeholder="Минимум 8 символов"
               :class="passwordClass" @input="validatePassword" autocomplete="new-password" />
        <div class="strength-bar"><div class="strength-fill" :style="strengthStyle"></div></div>
        <div class="field-hint" :class="passwordHintClass">{{ passwordHint }}</div>
      </div>

      <div class="form-group">
        <label>Подтвердите пароль</label>
        <input v-model="form.password2" type="password" placeholder="Повторите пароль"
               :class="password2Class" @input="validatePassword2" autocomplete="new-password" />
        <div class="field-hint" :class="password2HintClass">{{ password2Hint }}</div>
      </div>

      <button class="btn btn-block" :disabled="loading" @click="submit">
        <svg width="20" height="20" viewBox="0 0 24 24"><use href="#icon-check"/></svg>
        <span v-if="loading">Регистрация...</span>
        <span v-else>Зарегистрироваться</span>
      </button>

      <div class="auth-link">
        Уже есть аккаунт? <RouterLink to="/login">Войти</RouterLink>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import api from '@/composables/api'

const router = useRouter()

const form = ref({ username: '', email: '', password: '', password2: '' })
const error = ref('')
const loading = ref(false)

// Username
const usernameHint = ref('От 5 до 32 символов: буквы, цифры, _')
const usernameOk = ref(null)
const usernameClass = computed(() => usernameOk.value === true ? 'valid' : usernameOk.value === false ? 'invalid' : '')
const usernameHintClass = computed(() => usernameOk.value === true ? 'ok' : usernameOk.value === false ? 'error' : '')

function validateUsername() {
  const v = form.value.username
  const ok = /^[a-zA-Z0-9_]{5,32}$/.test(v)
  usernameOk.value = v.length ? ok : null
  if (!v.length) { usernameHint.value = 'От 5 до 32 символов: буквы, цифры, _'; return }
  if (v.length < 5) usernameHint.value = 'Минимум 5 символов'
  else if (v.length > 32) usernameHint.value = 'Максимум 32 символа'
  else if (!/^[a-zA-Z0-9_]+$/.test(v)) usernameHint.value = 'Только буквы, цифры и _'
  else usernameHint.value = 'Имя пользователя подходит'
}

// Email
const emailHint = ref('Введите действующий email')
const emailOk = ref(null)
const emailClass = computed(() => emailOk.value === true ? 'valid' : emailOk.value === false ? 'invalid' : '')
const emailHintClass = computed(() => emailOk.value === true ? 'ok' : emailOk.value === false ? 'error' : '')

function validateEmail() {
  const v = form.value.email
  const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)
  emailOk.value = v.length ? ok : null
  emailHint.value = ok ? 'Email выглядит правильно' : 'Введите корректный email'
}

// Password
const passwordHint = ref('Минимум 8 символов')
const passwordOk = ref(null)
const passwordClass = computed(() => passwordOk.value === true ? 'valid' : passwordOk.value === false ? 'invalid' : '')
const passwordHintClass = computed(() => passwordOk.value === true ? 'ok' : passwordOk.value === false ? 'error' : '')
const strengthStyle = ref('width:0')

function pwStrength(p) {
  let s = 0
  if (p.length >= 8) s++
  if (p.length >= 12) s++
  if (/[A-Z]/.test(p)) s++
  if (/[0-9]/.test(p)) s++
  if (/[^A-Za-z0-9]/.test(p)) s++
  return s
}

function validatePassword() {
  const v = form.value.password
  const s = pwStrength(v)
  const colors = ['', '#ff4757', '#ff6b35', '#ffa502', '#2ed573', '#2ed573']
  const labels = ['', 'Очень слабый', 'Слабый', 'Средний', 'Надёжный', 'Отличный']
  strengthStyle.value = `width:${v.length ? (s/5*100) : 0}%;background:${colors[s]}`
  passwordOk.value = v.length ? v.length >= 8 : null
  passwordHint.value = v.length ? (v.length < 8 ? 'Минимум 8 символов' : labels[s]) : 'Минимум 8 символов'
  if (form.value.password2) validatePassword2()
}

// Password2
const password2Hint = ref('')
const password2Ok = ref(null)
const password2Class = computed(() => password2Ok.value === true ? 'valid' : password2Ok.value === false ? 'invalid' : '')
const password2HintClass = computed(() => password2Ok.value === true ? 'ok' : password2Ok.value === false ? 'error' : '')

function validatePassword2() {
  const ok = form.value.password2 === form.value.password && form.value.password2.length > 0
  password2Ok.value = form.value.password2.length ? ok : null
  password2Hint.value = form.value.password2.length ? (ok ? 'Пароли совпадают' : 'Пароли не совпадают') : ''
}

async function submit() {
  validateUsername(); validateEmail(); validatePassword(); validatePassword2()
  const errs = []
  if (!usernameOk.value) errs.push('Имя пользователя: от 5 до 32 символов')
  if (!emailOk.value) errs.push('Введите корректный email')
  if (!passwordOk.value) errs.push('Пароль должен быть минимум 8 символов')
  if (!password2Ok.value) errs.push('Пароли не совпадают')
  if (errs.length) { error.value = errs[0]; return }

  loading.value = true
  error.value = ''
  try {
    await api.register(form.value)
    router.push('/login?success=Аккаунт создан. Войдите.')
  } catch (e) {
    error.value = e.response?.data?.error || 'Ошибка регистрации'
  } finally {
    loading.value = false
  }
}
</script>
