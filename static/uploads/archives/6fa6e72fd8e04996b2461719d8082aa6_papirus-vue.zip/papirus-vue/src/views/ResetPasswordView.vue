<template>
  <div class="auth-wrapper">
    <div class="auth-container">
      <div class="logo">
        <div class="logo-icon">
          <svg width="44" height="44" viewBox="0 0 24 24"><use href="#icon-chat"/></svg>
        </div>
        <h1>Сброс пароля</h1>
      </div>
      <div v-if="error" class="error-message">{{ error }}</div>
      <div v-if="success" class="success-message">{{ success }}</div>

      <div class="form-group">
        <label>Новый пароль</label>
        <input v-model="form.new_password" type="password" placeholder="Минимум 8 символов" />
        <div style="font-size:12px;color:var(--text-muted);margin-top:5px">Минимум 8 символов</div>
      </div>

      <div class="form-group">
        <label>Подтвердите пароль</label>
        <input v-model="form.confirm_password" type="password" placeholder="Повторите пароль" />
      </div>

      <div v-if="form.confirm_password && form.new_password !== form.confirm_password"
           style="color:var(--danger);font-size:13px;margin-bottom:15px">
        Пароли не совпадают
      </div>

      <button class="btn btn-block"
              :disabled="loading || (form.confirm_password && form.new_password !== form.confirm_password)"
              @click="submit">
        {{ loading ? 'Сохраняем...' : 'Сменить пароль' }}
      </button>

      <div style="text-align:center;margin-top:20px">
        <RouterLink to="/login" style="color:var(--text-secondary);text-decoration:none;font-size:14px">
          ← Вернуться ко входу
        </RouterLink>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import api from '@/composables/api'

const route = useRoute()
const router = useRouter()
const form = ref({ new_password: '', confirm_password: '' })
const error = ref('')
const success = ref('')
const loading = ref(false)

async function submit() {
  if (form.value.new_password !== form.value.confirm_password) return
  if (form.value.new_password.length < 8) { error.value = 'Пароль должен быть минимум 8 символов'; return }
  loading.value = true
  try {
    await api.resetPassword(route.params.token, form.value)
    success.value = 'Пароль успешно изменён'
    setTimeout(() => router.push('/login'), 2000)
  } catch (e) {
    error.value = e.response?.data?.error || 'Ошибка'
  } finally {
    loading.value = false
  }
}
</script>
