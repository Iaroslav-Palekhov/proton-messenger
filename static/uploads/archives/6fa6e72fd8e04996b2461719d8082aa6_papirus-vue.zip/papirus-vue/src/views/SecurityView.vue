<template>
  <div class="security-page">
    <div class="security-card">
      <div class="security-header">
        <RouterLink to="/chats" class="back-btn">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-back"/></svg>
        </RouterLink>
        <h1>Безопасность</h1>
      </div>

      <div class="menu-section" style="margin-top:20px">
        <div class="menu-section-title">Управление аккаунтом</div>
        <div class="menu-list">

          <RouterLink to="/security/password" class="menu-item">
            <div class="menu-item-icon icon-green">
              <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-lock"/></svg>
            </div>
            <div class="menu-item-text">
              <div class="menu-item-title">Пароль</div>
              <div class="menu-item-desc">Изменить пароль от аккаунта</div>
            </div>
            <div class="menu-item-arrow">
              <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-arrow-right"/></svg>
            </div>
          </RouterLink>

          <RouterLink to="/security/devices" class="menu-item">
            <div class="menu-item-icon icon-blue">
              <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-devices"/></svg>
            </div>
            <div class="menu-item-text">
              <div class="menu-item-title">Мои устройства</div>
              <div class="menu-item-desc">Активные сессии</div>
            </div>
            <div class="menu-item-arrow">
              <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-arrow-right"/></svg>
            </div>
          </RouterLink>

          <RouterLink to="/security/blacklist" class="menu-item">
            <div class="menu-item-icon icon-red">
              <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-block"/></svg>
            </div>
            <div class="menu-item-text">
              <div class="menu-item-title">Чёрный список</div>
              <div class="menu-item-desc">Заблокированные пользователи</div>
            </div>
            <div class="menu-item-arrow">
              <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-arrow-right"/></svg>
            </div>
          </RouterLink>

        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.menu-section { padding: 20px 16px 0; }
.menu-section-title { font-size: 12px; font-weight: 700; color: var(--accent); text-transform: uppercase; letter-spacing: .7px; margin-bottom: 10px; padding: 0 4px; }
.menu-list { background: var(--bg-tertiary); border-radius: 16px; overflow: hidden; }
.menu-item { display: flex; align-items: center; gap: 14px; padding: 16px; text-decoration: none; color: var(--text-primary); border-bottom: 1px solid var(--border); transition: background .15s; }
.menu-item:last-child { border-bottom: none; }
.menu-item:hover { background: var(--bg-hover); }
.menu-item-icon { width: 42px; height: 42px; border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.icon-green { background: rgba(34,197,94,.15); color: #4ade80; }
.icon-blue  { background: rgba(59,130,246,.15); color: #60a5fa; }
.icon-red   { background: rgba(239,68,68,.15);  color: #f87171; }
.menu-item-text { flex: 1; }
.menu-item-title { font-size: 15px; font-weight: 600; margin-bottom: 2px; }
.menu-item-desc { font-size: 12px; color: var(--text-muted); }
.menu-item-arrow { color: var(--text-muted); }
</style>
