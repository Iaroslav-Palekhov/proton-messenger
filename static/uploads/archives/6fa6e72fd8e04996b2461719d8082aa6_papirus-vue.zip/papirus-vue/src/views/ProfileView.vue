<template>
  <div class="security-page">
    <div class="security-card" style="max-width:560px">
      <div style="padding:16px">
        <button class="back-btn" @click="$router.go(-1)">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-back"/></svg>
        </button>
      </div>

      <div v-if="!user" style="text-align:center;padding:60px;color:var(--text-muted)">Загрузка...</div>

      <div v-else class="profile-container">
        <div class="profile-header">
          <div class="profile-avatar-wrap">
            <img :src="avatarUrl(user.avatar)" class="profile-avatar-img" />
            <RouterLink v-if="isMe" to="/edit-profile" class="edit-avatar-btn">
              <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-edit"/></svg>
            </RouterLink>
          </div>

          <h1 class="profile-name">{{ user.username }}</h1>
          <div class="profile-bio">{{ user.bio || 'Нет информации о себе' }}</div>

          <div class="profile-stats">
            <div class="stat-item">
              <div class="stat-value">{{ user.groups_count || 0 }}</div>
              <div class="stat-label">Групп</div>
            </div>
            <div class="stat-item">
              <div class="stat-value">{{ user.messages_count || 0 }}</div>
              <div class="stat-label">Сообщений</div>
            </div>
            <div class="stat-item">
              <div class="stat-value">
                <span class="status" :class="user.status || 'offline'"></span>
              </div>
              <div class="stat-label">
                {{ user.status === 'online' ? 'Онлайн' : 'Офлайн' }}
              </div>
            </div>
          </div>

          <!-- Actions for other users -->
          <template v-if="!isMe">
            <RouterLink :to="chatLink" class="btn" style="text-decoration:none;margin-bottom:10px">
              <svg width="20" height="20" viewBox="0 0 24 24"><use href="#icon-chat"/></svg>
              Написать сообщение
            </RouterLink>

            <button class="btn-block-user" :class="isBlocked ? 'btn-do-unblock' : 'btn-do-block'"
                    @click="toggleBlock">
              <svg v-if="isBlocked" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
              </svg>
              <svg v-else width="18" height="18" viewBox="0 0 24 24"><use href="#icon-block"/></svg>
              {{ isBlocked ? 'Разблокировать' : 'Заблокировать' }}
            </button>
          </template>

          <!-- Own profile actions -->
          <div v-if="isMe" style="margin-top:20px">
            <RouterLink to="/edit-profile" class="btn btn-secondary btn-block" style="text-decoration:none">
              <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-edit"/></svg>
              Редактировать профиль
            </RouterLink>
          </div>
        </div>

        <!-- Groups list -->
        <div style="margin-top:30px">
          <h2 style="margin-bottom:16px;font-size:18px;display:flex;align-items:center;gap:10px">
            <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-group"/></svg>
            Группы участника
          </h2>
          <div v-if="user.groups?.length">
            <RouterLink v-for="g in user.groups" :key="g.id" :to="`/group/${g.id}`" class="chat-item-link">
              <div class="chat-item-wrapper">
                <img :src="groupIconUrl(g.icon)" style="width:48px;height:48px;border-radius:50%;object-fit:cover" />
                <div style="flex:1;min-width:0">
                  <div style="font-weight:600;font-size:15px">{{ g.name }}</div>
                  <div style="font-size:13px;color:var(--text-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                    {{ g.description?.slice(0,60) }}
                  </div>
                </div>
                <span style="font-size:12px;color:var(--accent);background:rgba(0,168,132,.1);padding:2px 8px;border-radius:12px">{{ g.role }}</span>
              </div>
            </RouterLink>
          </div>
          <div v-else style="text-align:center;padding:30px;color:var(--text-muted)">Нет групп</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useToast } from '@/composables/useToast'
import api from '@/composables/api'

const route = useRoute()
const auth = useAuthStore()
const { showToast } = useToast()

const userId = computed(() => route.params.id === 'me' ? auth.user?.id : route.params.id)
const user = ref(null)
const isBlocked = ref(false)
const isMe = computed(() => userId.value == auth.user?.id)
const chatLink = computed(() => `/chat/start?user_id=${userId.value}`)

function avatarUrl(p) { return p ? `/static/uploads/${p}` : '/static/uploads/avatars/default.png' }
function groupIconUrl(p) { return p ? `/static/uploads/${p}` : '/static/uploads/group_icons/default.png' }

async function load() {
  try {
    const res = await api.getUser(userId.value)
    user.value = res.data.user
    isBlocked.value = res.data.is_blocked
  } catch { user.value = null }
}

async function toggleBlock() {
  try {
    if (isBlocked.value) {
      await api.unblockUser(userId.value)
      isBlocked.value = false
      showToast('Пользователь разблокирован')
    } else {
      await api.blockUser(userId.value)
      isBlocked.value = true
      showToast('Пользователь заблокирован')
    }
  } catch { showToast('Ошибка') }
}

onMounted(load)
</script>

<style scoped>
.profile-container { padding: 0 16px 40px; }
.profile-header { text-align: center; margin-bottom: 20px; }
.profile-avatar-wrap { position: relative; display: inline-block; margin-bottom: 16px; }
.profile-avatar-img { width: 130px; height: 130px; border-radius: 50%; object-fit: cover; border: 4px solid var(--accent); }
.edit-avatar-btn {
  position: absolute; bottom: 8px; right: 8px;
  background: var(--accent); color: white; border-radius: 50%;
  width: 36px; height: 36px; display: flex; align-items: center; justify-content: center;
  text-decoration: none; transition: transform .2s;
}
.edit-avatar-btn:hover { transform: scale(1.1); }
.profile-name { font-size: 26px; font-weight: 700; margin-bottom: 8px; }
.profile-bio { color: var(--text-secondary); font-size: 15px; margin-bottom: 20px; white-space: pre-wrap; }
.profile-stats { display: flex; justify-content: center; gap: 40px; margin-bottom: 24px; }
.stat-item { text-align: center; }
.stat-value { font-size: 22px; font-weight: 600; color: var(--accent); margin-bottom: 4px; display: flex; justify-content: center; align-items: center; }
.stat-label { color: var(--text-secondary); font-size: 13px; }

.btn-block-user {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  width: 100%; padding: 13px 16px; border-radius: 14px; font-size: 15px; font-weight: 600;
  border: none; cursor: pointer; font-family: inherit; transition: opacity .2s, transform .15s;
  margin-top: 10px; text-decoration: none;
}
.btn-block-user:active { transform: scale(0.97); }
.btn-do-block { background: rgba(239,68,68,.12); color: #f87171; border: 1.5px solid rgba(239,68,68,.3); }
.btn-do-block:hover { background: rgba(239,68,68,.2); }
.btn-do-unblock { background: rgba(251,146,60,.12); color: #fb923c; border: 1.5px solid rgba(251,146,60,.3); }
.btn-do-unblock:hover { background: rgba(251,146,60,.2); }

.chat-item-link { text-decoration: none; display: block; }
.chat-item-wrapper {
  display: flex; align-items: center; gap: 12px; padding: 12px;
  background: var(--bg-tertiary); border-radius: 12px; margin-bottom: 8px;
  border: 1px solid transparent; transition: var(--transition);
}
.chat-item-wrapper:hover { border-color: var(--accent); background: var(--bg-hover); }
</style>
