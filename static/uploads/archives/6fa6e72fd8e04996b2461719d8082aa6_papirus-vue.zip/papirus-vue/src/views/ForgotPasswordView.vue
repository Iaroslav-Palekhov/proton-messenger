<template>
  <div class="auth-wrapper">
    <div class="auth-container">
      <div class="logo">
        <div class="logo-icon">
          <svg width="44" height="44" viewBox="0 0 24 24"><use href="#icon-chat"/></svg>
        </div>
        <h1>Восстановление пароля</h1>
      </div>

      <div v-if="error" class="error-message">{{ error }}</div>
      <div v-if="success" class="success-message">{{ success }}</div>

      <div class="form-group">
        <label>Имя пользователя</label>
        <input v-model="form.username" type="text" placeholder="Введите имя пользователя" />
      </div>

      <div class="form-group">
        <label>Email</label>
        <input v-model="form.email" type="email" placeholder="Введите email" />
      </div>

      <button class="btn btn-block" :disabled="loading" @click="submit">
        {{ loading ? 'Отправка...' : 'Далее' }}
      </button>

      <div style="text-align:center;margin-top:20px">
        <RouterLink to="/login" style="color:var(--text-secondary);text-decoration:none;font-size:14px">
          ← Вернуться ко входу
        </RouterLink>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import api from '@/composables/api'

const form = ref({ username: '', email: '' })
const error = ref('')
const success = ref('')
const loading = ref(false)

async function submit() {
  error.value = ''
  loading.value = true
  try {
    await api.forgotPassword(form.value)
    success.value = 'Инструкции отправлены на email (если аккаунт существует)'
  } catch (e) {
    error.value = e.response?.data?.error || 'Ошибка'
  } finally {
    loading.value = false
  }
}
</script>
