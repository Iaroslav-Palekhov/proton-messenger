<template>
  <div class="edit-profile-page">
    <div class="edit-profile-card">
      <div class="edit-profile-header">
        <RouterLink :to="`/profile/${auth.user?.id}`" class="back-btn">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-back"/></svg>
        </RouterLink>
        <h1>Редактировать профиль</h1>
      </div>

      <div v-if="error" class="error-message">{{ error }}</div>
      <div v-if="success" class="success-message">{{ success }}</div>

      <!-- Avatar -->
      <div class="avatar-section">
        <div class="avatar-wrapper">
          <img :src="avatarPreview || avatarUrl(auth.user?.avatar)" class="avatar-preview-img" />
          <label class="avatar-edit-label">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
            <input type="file" accept="image/*" style="display:none" @change="onAvatarChange" />
          </label>
        </div>
        <p class="avatar-hint">Рекомендуемый размер: 500×500px</p>
      </div>

      <div class="form-group">
        <label>Имя пользователя</label>
        <input v-model="form.username" type="text" required minlength="5" autocomplete="off" />
        <div v-if="form.username.length > 0 && form.username.length < 5"
             style="color:var(--danger);font-size:13px;margin-top:6px">Минимум 5 символов</div>
      </div>

      <div class="form-group">
        <label style="display:flex;justify-content:space-between;align-items:center">
          <span>О себе</span>
          <span style="font-size:12px;color:var(--text-muted);font-weight:400">{{ form.bio.length }} / 150</span>
        </label>
        <textarea v-model="form.bio" maxlength="150" placeholder="Расскажите немного о себе..."></textarea>
      </div>

      <div class="form-actions">
        <button class="btn btn-primary" :disabled="saving" @click="save">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-check"/></svg>
          {{ saving ? 'Сохранение...' : 'Сохранить' }}
        </button>
        <RouterLink :to="`/profile/${auth.user?.id}`" class="btn btn-secondary">Отмена</RouterLink>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import api from '@/composables/api'

const router = useRouter()
const auth = useAuthStore()

const form = ref({ username: '', bio: '' })
const avatarPreview = ref(null)
const avatarFile = ref(null)
const saving = ref(false)
const error = ref('')
const success = ref('')

function avatarUrl(p) { return p ? `/static/uploads/${p}` : '/static/uploads/avatars/default.png' }

function onAvatarChange(e) {
  const f = e.target.files[0]
  if (!f) return
  avatarFile.value = f
  const reader = new FileReader()
  reader.onload = ev => { avatarPreview.value = ev.target.result }
  reader.readAsDataURL(f)
}

async function save() {
  if (form.value.username.length < 5) { error.value = 'Имя пользователя: минимум 5 символов'; return }
  saving.value = true
  error.value = ''
  try {
    const fd = new FormData()
    fd.append('username', form.value.username)
    fd.append('bio', form.value.bio)
    if (avatarFile.value) fd.append('avatar', avatarFile.value)
    await api.updateProfile(fd)
    await auth.fetchMe()
    success.value = 'Профиль сохранён'
    setTimeout(() => router.push(`/profile/${auth.user?.id}`), 1000)
  } catch (e) {
    error.value = e.response?.data?.error || 'Ошибка при сохранении'
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  form.value.username = auth.user?.username || ''
  form.value.bio = auth.user?.bio || ''
})
</script>

<style scoped>
.edit-profile-page {
  min-height: 100vh; background: var(--bg-primary);
  display: flex; align-items: flex-start; justify-content: center;
  padding: 20px 16px 40px; overflow-y: auto;
}
.edit-profile-card {
  background: var(--bg-secondary); border-radius: 20px; padding: 32px 28px;
  width: 100%; max-width: 480px;
}
.edit-profile-header { display: flex; align-items: center; gap: 14px; margin-bottom: 28px; }
.edit-profile-header h1 { font-size: 20px; font-weight: 700; margin: 0; }

.avatar-section { display: flex; flex-direction: column; align-items: center; margin-bottom: 28px; }
.avatar-wrapper { position: relative; display: inline-block; }
.avatar-preview-img { width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 3px solid var(--accent); display: block; }
.avatar-edit-label {
  position: absolute; bottom: 2px; right: 2px;
  background: var(--accent); border-radius: 50%; width: 32px; height: 32px;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,.3); transition: transform .2s;
}
.avatar-edit-label:hover { transform: scale(1.1); }
.avatar-hint { margin-top: 10px; font-size: 12px; color: var(--text-muted); }

.form-actions { display: flex; gap: 10px; margin-top: 24px; }
.form-actions .btn { flex: 1; }
.btn-primary { background: var(--accent); color: white; }
.btn-primary:hover { opacity: .9; }

@media (max-width: 520px) {
  .edit-profile-page { padding: 0; }
  .edit-profile-card { border-radius: 0; min-height: 100vh; padding: 20px 16px; }
}
</style>
