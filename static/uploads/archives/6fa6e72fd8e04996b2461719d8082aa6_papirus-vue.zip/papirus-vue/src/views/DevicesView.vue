<template>
  <div class="security-page">
    <div class="security-card">
      <div class="security-header">
        <RouterLink to="/security" class="back-btn">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-back"/></svg>
        </RouterLink>
        <h1>Мои устройства</h1>
      </div>

      <div class="section" style="margin-top:20px">
        <!-- Current session -->
        <div class="section-title">Текущий сеанс</div>
        <div v-if="currentSession" class="section-card">
          <div class="session-item">
            <div class="session-icon current">
              <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-devices"/></svg>
            </div>
            <div class="session-info">
              <div class="session-device">{{ currentSession.browser }} · {{ currentSession.os }}</div>
              <div class="session-meta">{{ currentSession.ip_address }} · Сейчас</div>
              <div class="session-badge">Текущий сеанс</div>
            </div>
          </div>
        </div>

        <!-- Other sessions -->
        <div v-if="otherSessions.length" style="margin-top:16px">
          <div class="section-title">Другие сеансы</div>
          <div class="section-card">
            <div v-for="(s, i) in otherSessions" :key="s.id" class="session-item"
                 :style="i < otherSessions.length - 1 ? 'border-bottom:1px solid var(--border)' : ''">
              <div class="session-icon">
                <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-devices"/></svg>
              </div>
              <div class="session-info">
                <div class="session-device">{{ s.browser || 'Неизвестное устройство' }} · {{ s.os || '' }}</div>
                <div class="session-meta">{{ s.ip_address }} · {{ s.last_active_str }}</div>
              </div>
              <button class="session-terminate" @click="terminate(s)" title="Завершить">
                <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-close"/></svg>
              </button>
            </div>
          </div>
          <button class="btn btn-danger btn-block" style="margin-top:12px" @click="terminateAll">
            Завершить все другие сеансы
          </button>
        </div>

        <div v-if="!currentSession && !otherSessions.length" style="text-align:center;padding:40px;color:var(--text-muted)">
          Загрузка...
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useToast } from '@/composables/useToast'
import api from '@/composables/api'

const { showToast } = useToast()
const sessions = ref([])
const currentSession = computed(() => sessions.value.find(s => s.is_current))
const otherSessions = computed(() => sessions.value.filter(s => !s.is_current))

async function load() {
  const res = await api.getSessions()
  sessions.value = res.data || []
}

async function terminate(s) {
  if (!confirm('Завершить этот сеанс?')) return
  try {
    await api.terminateSession(s.id)
    sessions.value = sessions.value.filter(x => x.id !== s.id)
    showToast('Сеанс завершён')
  } catch { showToast('Ошибка') }
}

async function terminateAll() {
  if (!confirm('Завершить все другие сеансы?')) return
  try {
    await api.terminateAllSessions()
    sessions.value = sessions.value.filter(s => s.is_current)
    showToast('Все другие сеансы завершены')
  } catch { showToast('Ошибка') }
}

onMounted(load)
</script>

<style scoped>
.session-item {
  display: flex; align-items: flex-start; gap: 14px; padding: 14px 16px; position: relative;
}
.session-icon {
  width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center;
  justify-content: center; flex-shrink: 0; background: var(--bg-secondary); color: var(--text-secondary);
}
.session-icon.current { background: rgba(0,168,132,.15); color: var(--accent); }
.session-info { flex: 1; min-width: 0; }
.session-device { font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 4px; }
.session-meta { font-size: 12px; color: var(--text-muted); margin-bottom: 4px; }
.session-badge { display: inline-block; background: rgba(0,168,132,.15); color: var(--accent); font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 10px; }
.session-terminate {
  background: transparent; border: none; color: var(--text-muted); cursor: pointer;
  padding: 6px; border-radius: 8px; display: flex; align-items: center; transition: all .2s;
}
.session-terminate:hover { background: var(--danger-bg); color: var(--danger); }
</style>
