import { defineStore } from 'pinia'
import { ref } from 'vue'
import api from '@/composables/api'

export const useAuthStore = defineStore('auth', () => {
  const user = ref(null)
  const loading = ref(false)

  async function fetchMe() {
    try {
      const res = await api.getMe()
      user.value = res.data
    } catch {
      user.value = null
    }
  }

  async function logout() {
    await api.logout()
    user.value = null
  }

  return { user, loading, fetchMe, logout }
})
