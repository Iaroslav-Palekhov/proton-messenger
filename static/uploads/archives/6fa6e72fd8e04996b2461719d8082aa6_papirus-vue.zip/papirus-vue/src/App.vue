<template>
  <SvgSprite />
  <RouterView />
  <Teleport to="body">
    <div class="toast" :class="{ show: toastVisible }">{{ toastText }}</div>
  </Teleport>
</template>

<script setup>
import SvgSprite from '@/components/SvgSprite.vue'
import { useToast } from '@/composables/useToast'

const { toastText, toastVisible } = useToast()
</script>
