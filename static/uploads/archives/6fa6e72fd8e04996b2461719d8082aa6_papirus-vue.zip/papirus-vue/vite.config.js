import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { fileURLToPath, URL } from 'node:url'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:2200',
        changeOrigin: true
      },
      '/static': {
        target: 'http://localhost:2200',
        changeOrigin: true
      },
      '/socket.io': {
        target: 'http://localhost:2200',
        ws: true,
        changeOrigin: true
      }
    }
  }
})
