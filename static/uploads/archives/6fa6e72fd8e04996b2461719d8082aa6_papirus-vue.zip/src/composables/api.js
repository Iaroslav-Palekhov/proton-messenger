import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  withCredentials: true
})

api.interceptors.response.use(
  r => r,
  err => {
    if (err.response?.status === 401 && window.location.pathname !== '/login') {
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export default {
  // Auth
  login:          (data) => api.post('/auth/login', data),
  register:       (data) => api.post('/auth/register', data),
  logout:         ()     => api.post('/auth/logout'),
  getMe:          ()     => api.get('/auth/me'),
  forgotPassword: (data) => api.post('/auth/forgot_password', data),
  resetPassword:  (data) => api.post('/auth/reset_password', data),   // body: token, new_password, confirm_password

  // Users
  getUser:      (id) => api.get(`/users/${id}`),
  searchUsers:  (q)  => api.get(`/users/search?q=${encodeURIComponent(q)}`),
  updateProfile:(fd) => api.patch('/profile/edit', fd),               // FormData: username?, bio?, avatar?

  // Chats (combined list)
  getChats:     ()   => api.get('/chats'),
  createChat:   (data) => api.post('/chats/start', data),             // body: username
  deleteChat:   (id)   => api.delete(`/chats/${id}`),

  // Messages
  // GET /api/messages/:id?is_group=false&last_id=0
  getChatMessages:  (chatId, lastId = 0) =>
    api.get(`/messages/${chatId}?is_group=false&last_id=${lastId}`),
  getGroupMessages: (groupId, lastId = 0) =>
    api.get(`/messages/${groupId}?is_group=true&last_id=${lastId}`),

  // GET /api/chats/:id  — full chat info + messages
  getChatInfo:  (id) => api.get(`/chats/${id}`),
  // GET /api/groups/:id — full group info + messages
  getGroupInfo: (id) => api.get(`/groups/${id}`),

  // POST /api/messages  body: chat_id|group_id, content?, file?, reply_to_id?
  sendMessage: (data) => api.post('/messages', data),  // FormData

  // PATCH /api/messages/:id  body: content
  editMessage:   (msgId, data) => api.patch(`/messages/${msgId}`, data),
  // DELETE /api/messages/:id
  deleteMessage: (msgId)       => api.delete(`/messages/${msgId}`),

  // POST /api/messages/forward
  forwardMessage: (data) => api.post('/messages/forward', data),

  // Pin
  pinMessage:   (msgId) => api.post(`/messages/${msgId}/pin`),
  unpinMessage: (msgId) => api.post(`/messages/${msgId}/unpin`),
  getPinned:    (contextId, isGroup = false) =>
    api.get(`/pinned/${contextId}?is_group=${isGroup}`),

  // Groups
  getGroups:         ()         => api.get('/groups'),
  createGroup:       (fd)       => api.post('/groups', fd),            // FormData: name, description?, icon?
  getGroup:          (id)       => api.get(`/groups/${id}`),
  updateGroup:       (id, fd)   => api.patch(`/groups/${id}`, fd),
  deleteGroup:       (id)       => api.delete(`/groups/${id}`),
  leaveGroup:        (id)       => api.post(`/groups/${id}/leave`),
  getGroupMembers:   (id)       => api.get(`/groups/${id}/members`),
  addGroupMember:    (id, data) => api.post(`/groups/${id}/members`, data),
  removeGroupMember: (id, uid)  => api.delete(`/groups/${id}/members/${uid}`),
  changeGroupRole:   (id, uid, data) => api.patch(`/groups/${id}/members/${uid}/role`, data),

  // Security
  changePassword:      (data) => api.post('/security/change_password', data),
  getSessions:         ()     => api.get('/security/sessions'),
  terminateSession:    (id)   => api.delete(`/security/sessions/${id}`),
  terminateAllSessions:()     => api.delete('/security/sessions'),
  getBlockedUsers:     ()     => api.get('/security/blacklist'),
  blockUser:           (id)   => api.post(`/security/block/${id}`),
  unblockUser:         (id)   => api.post(`/security/unblock/${id}`),

  // Misc
  getUnread:          ()                 => api.get('/unread'),
  getForwardTargets:  ()                 => api.get('/forward_targets'),
  searchMessages:     (ctxId, q, group)  => api.get(`/search/${ctxId}?q=${encodeURIComponent(q)}&is_group=${group}`),
  getMedia:           (ctxId, type, grp) => api.get(`/media/${ctxId}?type=${type}&is_group=${grp}`),
}
