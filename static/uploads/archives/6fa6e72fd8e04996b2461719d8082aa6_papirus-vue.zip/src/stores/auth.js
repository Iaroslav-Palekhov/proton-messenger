import { defineStore } from 'pinia'
import { ref } from 'vue'
import api from '@/composables/api'

export const useAuthStore = defineStore('auth', () => {
  const user = ref(null)
  const loading = ref(false)

  async function fetchMe() {
    try {
      const res = await api.getMe()
      user.value = res.data
    } catch {
      user.value = null
    }
  }

  async function logout() {
    try { await api.logout() } catch {}
    user.value = null
    // Reset router guard so next visit re-checks session
    try {
      const { resetUserChecked } = await import('@/router/index.js')
      resetUserChecked()
    } catch {}
  }

  return { user, loading, fetchMe, logout }
})
