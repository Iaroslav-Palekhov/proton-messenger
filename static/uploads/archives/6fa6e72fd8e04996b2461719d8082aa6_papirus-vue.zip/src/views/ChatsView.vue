<template>
  <div class="chats-fullscreen">
    <!-- Drawer overlay -->
    <Transition name="fade">
      <div v-if="drawerOpen" class="drawer-overlay" @click="drawerOpen = false"></div>
    </Transition>

    <!-- Drawer -->
    <Transition name="slide-left">
      <div v-if="drawerOpen" class="drawer">
        <div class="drawer-header">
          <div class="drawer-avatar-wrap">
            <img :src="avatarUrl(auth.user?.avatar)" class="drawer-avatar" />
          </div>
          <div class="drawer-user-info">
            <div class="drawer-username">{{ auth.user?.username }}</div>
            <div class="drawer-email">{{ auth.user?.email }}</div>
          </div>
        </div>
        <div class="drawer-menu">
          <RouterLink to="/profile/me" class="drawer-item" @click="drawerOpen = false">
            <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-profile"/></svg>
            Профиль
          </RouterLink>
          <RouterLink to="/security" class="drawer-item" @click="drawerOpen = false">
            <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-security"/></svg>
            Безопасность
          </RouterLink>
          <div class="drawer-item danger" @click="handleLogout">
            <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-logout"/></svg>
            Выйти
          </div>
        </div>
      </div>
    </Transition>

    <!-- Header -->
    <div class="chats-header">
      <div class="header-left">
        <button class="burger-btn" @click="drawerOpen = true">
          <span></span><span></span><span></span>
        </button>
        <span class="header-title">Papirus</span>
      </div>
      <div class="header-actions">
        <button class="btn-icon" @click="showNewChatModal = true" title="Новый чат">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-chat"/></svg>
        </button>
        <button class="btn-icon" @click="showNewGroupModal = true" title="Новая группа">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-group"/></svg>
        </button>
      </div>
    </div>

    <!-- Search -->
    <div class="search-bar">
      <svg width="18" height="18" viewBox="0 0 24 24" style="color:var(--text-muted);flex-shrink:0">
        <use href="#icon-search"/>
      </svg>
      <input v-model="searchQ" type="text" placeholder="Поиск" />
    </div>

    <!-- Tabs -->
    <div class="chats-title">
      <span>Все чаты</span>
    </div>

    <!-- Chat list -->
    <div class="chats-list">
      <div v-if="loading" style="text-align:center;padding:40px;color:var(--text-muted)">
        Загрузка...
      </div>
      <div v-else-if="filteredItems.length === 0" class="empty-chats">
        <svg width="64" height="64" viewBox="0 0 24 24" class="empty-icon">
          <use href="#icon-chat"/>
        </svg>
        <h3>Нет чатов</h3>
        <p>Начните новый чат или вступите в группу</p>
      </div>
      <template v-else>
        <div v-for="item in filteredItems" :key="item.key" class="chat-item-wrapper">
          <RouterLink :to="item.isGroup ? `/group/${item.id}` : `/chat/${item.id}`" class="chat-item">
            <div class="chat-avatar">
              <img :src="item.isGroup ? groupIconUrl(item.icon) : avatarUrl(item.avatar)"
                   :alt="item.name" @error="onImgError" />
              <span v-if="!item.isGroup" class="status" :class="item.status || 'offline'"></span>
              <span v-if="item.unread" class="unread-badge">{{ item.unread > 99 ? '99+' : item.unread }}</span>
            </div>
            <div class="chat-info">
              <div class="chat-header-row">
                <h3>{{ item.name }}</h3>
                <span class="chat-time">{{ formatTime(item.last_message_at) }}</span>
              </div>
              <div class="chat-preview">
                <p>
                  <span v-if="item.lastMsg?.sender_id === auth.user?.id" class="you-label">Вы: </span>
                  <span v-else-if="item.isGroup && item.lastMsg?.sender_name" class="sender-label">{{ item.lastMsg.sender_name }}: </span>
                  {{ item.lastMsg?.preview || (item.isGroup ? item.description : '') }}
                </p>
                <span v-if="item.unread" class="chat-badge">{{ item.unread }}</span>
              </div>
            </div>
          </RouterLink>
          <button class="delete-chat-btn" @click.stop="deleteItem(item)" title="Удалить">
            <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-delete"/></svg>
          </button>
        </div>
      </template>
    </div>

    <!-- New chat modal -->
    <Teleport to="body">
      <div v-if="showNewChatModal" class="modal-overlay" @click.self="showNewChatModal = false">
        <div class="modal-content">
          <div class="modal-header">
            <h2>Новый чат</h2>
            <button class="close-modal" @click="showNewChatModal = false">×</button>
          </div>
          <div class="form-group">
            <label>Имя пользователя</label>
            <input v-model="newChatUsername" type="text" placeholder="Введите username"
                   @keyup.enter="startChat" />
          </div>
          <div v-if="chatError" class="error-message" style="margin-bottom:10px">{{ chatError }}</div>
          <div class="modal-actions">
            <button class="btn" @click="startChat">Написать</button>
            <button class="btn btn-secondary" @click="showNewChatModal = false">Отмена</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- New group modal -->
    <Teleport to="body">
      <div v-if="showNewGroupModal" class="modal-overlay" @click.self="showNewGroupModal = false">
        <div class="modal-content">
          <div class="modal-header">
            <h2>Новая группа</h2>
            <button class="close-modal" @click="showNewGroupModal = false">×</button>
          </div>
          <div class="form-group">
            <label>Название группы</label>
            <input v-model="newGroup.name" type="text" placeholder="Введите название" />
          </div>
          <div class="form-group">
            <label>Описание (необязательно)</label>
            <textarea v-model="newGroup.description" placeholder="Описание группы"></textarea>
          </div>
          <div v-if="groupError" class="error-message" style="margin-bottom:10px">{{ groupError }}</div>
          <div class="modal-actions">
            <button class="btn" @click="createGroup">Создать</button>
            <button class="btn btn-secondary" @click="showNewGroupModal = false">Отмена</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useSocket } from '@/composables/useSocket'
import api from '@/composables/api'

const router = useRouter()
const auth = useAuthStore()
const { connect, getSocket } = useSocket()

const drawerOpen = ref(false)
const searchQ = ref('')
const loading = ref(true)
const chats = ref([])
const groups = ref([])

const showNewChatModal = ref(false)
const newChatUsername = ref('')
const chatError = ref('')

const showNewGroupModal = ref(false)
const newGroup = ref({ name: '', description: '' })
const groupError = ref('')

function avatarUrl(path) {
  if (!path) return '/static/uploads/avatars/default.png'
  if (path.startsWith('/')) return path
  return `/static/uploads/${path}`
}
function groupIconUrl(path) {
  if (!path) return '/static/uploads/group_icons/default.png'
  if (path.startsWith('/')) return path
  return `/static/uploads/${path}`
}
function onImgError(e) { e.target.src = '/static/uploads/avatars/default.png' }

function formatTime(ts) {
  if (!ts) return ''
  const d = new Date(ts)
  const now = new Date()
  if (d.toDateString() === now.toDateString()) {
    return d.toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' })
  }
  return d.toLocaleDateString('ru', { day: '2-digit', month: '2-digit' })
}

const allItems = computed(() => {
  const c = chats.value.map(ch => ({
    ...ch,
    key: `chat-${ch.id}`,
    isGroup: false,
    name: ch.other_username,
    avatar: ch.other_avatar?.replace('/static/uploads/', ''),
    status: ch.other_status,
    unread: ch.unread_count,
    lastMsg: { preview: ch.last_message, sender_id: null },
    last_message_at: ch.last_message_time,
  }))
  const g = groups.value.map(gr => ({
    ...gr,
    key: `group-${gr.id}`,
    isGroup: true,
    name: gr.group_name,
    icon: gr.group_icon?.replace('/static/uploads/', ''),
    unread: gr.unread_count,
    lastMsg: { preview: gr.last_message },
    last_message_at: gr.last_message_time,
  }))
  return [...c, ...g].sort((a, b) => (b.last_message_at || '').localeCompare(a.last_message_at || ''))
})

const filteredItems = computed(() => {
  if (!searchQ.value) return allItems.value
  const q = searchQ.value.toLowerCase()
  return allItems.value.filter(i => i.name?.toLowerCase().includes(q))
})

async function load() {
  loading.value = true
  try {
    // /api/chats returns {chats: [...], total_unread: N}
    // chats array has both private (type:'private') and group (type:'group') items
    const res = await api.getChats()
    const all = res.data?.chats || []
    chats.value  = all.filter(c => c.type === 'private')
    groups.value = all.filter(c => c.type === 'group')
  } finally {
    loading.value = false
  }
}

async function startChat() {
  chatError.value = ''
  if (!newChatUsername.value.trim()) { chatError.value = 'Введите имя пользователя'; return }
  try {
    const res = await api.createChat({ username: newChatUsername.value.trim() })
    showNewChatModal.value = false
    newChatUsername.value = ''
    router.push(`/chat/${res.data.chat_id}`)
  } catch (e) {
    chatError.value = e.response?.data?.error || 'Пользователь не найден'
  }
}

async function createGroup() {
  groupError.value = ''
  if (!newGroup.value.name.trim()) { groupError.value = 'Введите название'; return }
  try {
    const res = await api.createGroup(newGroup.value)
    showNewGroupModal.value = false
    newGroup.value = { name: '', description: '' }
    router.push(`/group/${res.data.group_id}`)
  } catch (e) {
    groupError.value = e.response?.data?.error || 'Ошибка создания группы'
  }
}

async function deleteItem(item) {
  if (!confirm(`Удалить ${item.isGroup ? 'группу' : 'чат'} "${item.name}"?`)) return
  try {
    if (item.isGroup) {
      await api.leaveGroup(item.id)
    } else {
      await api.deleteChat(item.id)
    }
    await load()
  } catch (e) {
    alert(e.response?.data?.error || 'Ошибка')
  }
}

async function handleLogout() {
  await auth.logout()
  router.push('/login')
}

onMounted(async () => {
  await load()
  const socket = connect()
  socket.emit('join_user_room')
  socket.on('new_message', () => load())
  socket.on('new_group_message', () => load())
})
</script>

<style scoped>
.chats-fullscreen {
  width: 100vw; height: 100vh;
  background: var(--bg-secondary);
  display: flex; flex-direction: column;
  overflow: hidden; position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
}

.chats-header {
  padding: 12px 16px;
  background: var(--bg-secondary);
  display: flex; justify-content: space-between; align-items: center;
  border-bottom: 1px solid var(--border);
  flex-shrink: 0; height: 56px;
}

.header-left { display: flex; align-items: center; gap: 14px; }

.burger-btn {
  width: 40px; height: 40px; border-radius: 50%;
  background: transparent; border: none; color: var(--text-primary);
  cursor: pointer; display: flex; align-items: center; justify-content: center;
  flex-direction: column; gap: 5px; transition: background 0.2s;
}
.burger-btn:hover { background: var(--bg-tertiary); }
.burger-btn span { display: block; width: 20px; height: 2px; background: var(--text-primary); border-radius: 2px; }

.header-title { font-size: 20px; font-weight: 700; color: var(--text-primary); }
.header-actions { display: flex; gap: 10px; }

.search-bar {
  padding: 10px 15px; background: var(--bg-tertiary);
  margin: 10px 15px; border-radius: 24px;
  display: flex; align-items: center; gap: 10px; flex-shrink: 0;
}
.search-bar input { background: transparent; border: none; color: var(--text-primary); width: 100%; font-size: 15px; outline: none; }
.search-bar input::placeholder { color: var(--text-muted); }

.chats-title {
  padding: 0 15px 10px; border-bottom: 1px solid var(--border); flex-shrink: 0;
}
.chats-title span {
  padding: 10px 0; color: var(--accent); border-bottom: 2px solid var(--accent);
  font-weight: 600; display: inline-block;
}

.chats-list { flex: 1; overflow-y: auto; padding: 10px 15px; }

.chat-item-wrapper {
  display: flex; align-items: center; gap: 8px;
  margin-bottom: 8px; background: var(--bg-tertiary);
  border-radius: 12px; border: 1px solid transparent; transition: var(--transition);
}
.chat-item-wrapper:hover { border-color: var(--accent); background: var(--bg-hover); }

.chat-item {
  flex: 1; display: flex; align-items: center; padding: 12px;
  text-decoration: none; color: var(--text-primary);
}

.chat-avatar { position: relative; margin-right: 12px; flex-shrink: 0; }
.chat-avatar img { width: 50px; height: 50px; border-radius: 50%; object-fit: cover; }
.chat-avatar .status { position: absolute; bottom: 0; right: 0; width: 12px; height: 12px; border: 2px solid var(--bg-tertiary); }
.unread-badge {
  position: absolute; top: -5px; right: -5px;
  background: var(--accent); color: white; border-radius: 50%;
  width: 22px; height: 22px; font-size: 12px;
  display: flex; justify-content: center; align-items: center;
  font-weight: bold; border: 2px solid var(--bg-tertiary);
}

.chat-info { flex: 1; min-width: 0; }
.chat-header-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
.chat-header-row h3 { font-size: 16px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin: 0; }
.chat-time { font-size: 11px; color: var(--text-muted); white-space: nowrap; margin-left: 8px; }
.chat-preview { display: flex; justify-content: space-between; align-items: center; }
.chat-preview p { font-size: 13px; color: var(--text-secondary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin: 0; max-width: 200px; }
.you-label, .sender-label { color: var(--text-muted); }
.chat-badge { background: var(--accent); color: white; border-radius: 12px; padding: 2px 8px; font-size: 11px; font-weight: 600; }

.delete-chat-btn {
  background: transparent; border: none; color: var(--text-muted);
  font-size: 18px; padding: 8px 12px; border-radius: 8px;
  cursor: pointer; transition: var(--transition); display: flex; align-items: center; opacity: 0.7;
}
.delete-chat-btn:hover { background: var(--danger-bg); color: var(--danger); opacity: 1; }

.empty-chats { text-align: center; padding: 60px 20px; color: var(--text-muted); }
.empty-icon { display: block; margin: 0 auto 20px; }
.empty-chats h3 { margin-bottom: 10px; color: var(--text-primary); }

/* Drawer */
.drawer-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 100;
}
.drawer {
  position: fixed; left: 0; top: 0; bottom: 0;
  width: 280px; background: var(--bg-secondary);
  z-index: 101; display: flex; flex-direction: column;
  box-shadow: 4px 0 20px rgba(0,0,0,0.4);
}
.drawer-header {
  padding: 30px 20px 20px;
  background: var(--bg-tertiary);
  display: flex; align-items: center; gap: 14px;
  border-bottom: 1px solid var(--border);
}
.drawer-avatar { width: 52px; height: 52px; border-radius: 50%; object-fit: cover; border: 2px solid var(--accent); flex-shrink: 0; }
.drawer-username { font-size: 17px; font-weight: 700; }
.drawer-email { font-size: 13px; color: var(--text-secondary); margin-top: 2px; }
.drawer-menu { padding: 10px 0; flex: 1; }
.drawer-item {
  display: flex; align-items: center; gap: 14px;
  padding: 16px 20px; color: var(--text-primary);
  text-decoration: none; cursor: pointer; transition: background 0.2s; font-size: 15px;
}
.drawer-item:hover { background: var(--bg-hover); }
.drawer-item.danger { color: var(--danger); }

/* Transitions */
.fade-enter-active, .fade-leave-active { transition: opacity 0.25s; }
.fade-enter-from, .fade-leave-to { opacity: 0; }

.slide-left-enter-active, .slide-left-leave-active { transition: transform 0.25s ease; }
.slide-left-enter-from, .slide-left-leave-to { transform: translateX(-100%); }
</style>
