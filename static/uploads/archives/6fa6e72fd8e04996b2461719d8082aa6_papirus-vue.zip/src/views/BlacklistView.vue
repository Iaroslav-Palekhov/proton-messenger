<template>
  <div class="security-page">
    <div class="security-card">
      <div class="security-header">
        <RouterLink to="/security" class="back-btn">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-back"/></svg>
        </RouterLink>
        <h1>Чёрный список</h1>
      </div>

      <div class="section" style="margin-top:20px">
        <div class="section-title">{{ blocked.length }} заблокированных</div>

        <div v-if="blocked.length === 0" style="text-align:center;padding:60px 20px;color:var(--text-muted)">
          <svg width="48" height="48" viewBox="0 0 24 24" style="display:block;margin:0 auto 16px;opacity:.4">
            <use href="#icon-block"/>
          </svg>
          <p>Список пуст</p>
        </div>

        <div v-else class="section-card">
          <div v-for="(u, i) in blocked" :key="u.id" class="blocked-item"
               :style="i < blocked.length - 1 ? 'border-bottom:1px solid var(--border)' : ''">
            <RouterLink :to="`/profile/${u.user_id}`">
              <img :src="avatarUrl(u.avatar)" class="blocked-avatar" />
            </RouterLink>
            <div class="blocked-info">
              <div class="blocked-name">{{ u.username }}</div>
              <div class="blocked-meta">Заблокирован {{ formatDate(u.blocked_at) }}</div>
            </div>
            <button class="btn btn-sm" style="background:rgba(251,146,60,.12);color:#fb923c;border:1.5px solid rgba(251,146,60,.3)"
                    @click="unblock(u)">
              Разблокировать
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useToast } from '@/composables/useToast'
import api from '@/composables/api'

const { showToast } = useToast()
const blocked = ref([])

function avatarUrl(p) {
  if (!p) return '/static/uploads/avatars/default.png'
  if (p.startsWith('/')) return p
  return `/static/uploads/${p}`
}
function formatDate(ts) {
  if (!ts) return ''
  return new Date(ts).toLocaleDateString('ru', { day: '2-digit', month: '2-digit', year: 'numeric' })
}

async function load() {
  const res = await api.getBlockedUsers()
  // Returns [{id, user_id, username, avatar, blocked_at}]
  blocked.value = res.data || []
}

async function unblock(u) {
  try {
    await api.unblockUser(u.user_id)
    blocked.value = blocked.value.filter(x => x.id !== u.id)
    showToast('Пользователь разблокирован')
  } catch { showToast('Ошибка') }
}

onMounted(load)
</script>

<style scoped>
.blocked-item {
  display: flex; align-items: center; gap: 12px; padding: 12px 16px; transition: background .15s;
}
.blocked-item:hover { background: rgba(255,255,255,.03); }
.blocked-avatar { width: 44px; height: 44px; border-radius: 50%; object-fit: cover; filter: grayscale(60%); opacity: .7; }
.blocked-info { flex: 1; min-width: 0; }
.blocked-name { font-weight: 600; font-size: 15px; }
.blocked-meta { font-size: 12px; color: var(--text-muted); margin-top: 3px; }
</style>
