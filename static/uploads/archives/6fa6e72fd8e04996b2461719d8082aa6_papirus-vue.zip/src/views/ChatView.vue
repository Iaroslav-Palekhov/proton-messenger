<template>
  <div class="chat-container">
    <!-- Header -->
    <div class="chat-header">
      <div class="chat-user-info">
        <RouterLink to="/chats" class="btn-icon" style="margin-right:4px">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-back"/></svg>
        </RouterLink>
        <RouterLink :to="`/profile/${otherUser?.id}`" class="chat-avatar-link">
          <div class="chat-avatar-wrap">
            <img :src="avatarUrl(otherUser?.avatar)" class="chat-avatar-img" @error="onImgError" />
          </div>
        </RouterLink>
        <div class="chat-user-details">
          <h2>{{ otherUser?.username || '...' }}</h2>
          <p>
            <span class="status" :class="otherUser?.status || 'offline'"></span>
            {{ otherUser?.status === 'online' ? 'онлайн' : 'был(а) недавно' }}
          </p>
        </div>
      </div>
      <div class="header-actions">
        <button class="btn-icon" @click="showSearch = !showSearch" title="Поиск">
          <svg width="20" height="20" viewBox="0 0 24 24"><use href="#icon-search"/></svg>
        </button>
        <RouterLink :to="`/profile/${otherUser?.id}`" class="btn-icon" title="Профиль">
          <svg width="20" height="20" viewBox="0 0 24 24"><use href="#icon-info"/></svg>
        </RouterLink>
      </div>
    </div>

    <!-- Search bar -->
    <Transition name="slide-down">
      <div v-if="showSearch" class="msg-search-bar">
        <svg width="16" height="16" viewBox="0 0 24 24" style="color:var(--text-muted)"><use href="#icon-search"/></svg>
        <input v-model="searchMsg" type="text" placeholder="Поиск в сообщениях" />
      </div>
    </Transition>

    <!-- Reply / Edit bar -->
    <Transition name="slide-down">
      <div v-if="replyTo || editMsg" class="reply-bar">
        <div class="reply-bar-inner">
          <div class="reply-line"></div>
          <div class="reply-info">
            <span class="reply-label">{{ editMsg ? 'Редактирование' : `Ответ: ${replyTo?.sender?.username}` }}</span>
            <span class="reply-text">{{ editMsg?.content || replyTo?.content }}</span>
          </div>
        </div>
        <button class="reply-close" @click="clearReply">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-close"/></svg>
        </button>
      </div>
    </Transition>

    <!-- Messages -->
    <div class="messages-container" ref="msgsEl" @scroll="onScroll">
      <div v-if="loadingMore" style="text-align:center;padding:10px;color:var(--text-muted);font-size:13px">
        Загрузка...
      </div>
      <div v-for="msg in filteredMessages" :key="msg.id"
           class="message" :class="msg.sender_id === auth.user?.id ? 'sent' : 'received'"
           :id="`msg-${msg.id}`"
           @contextmenu.prevent="showCtxMenu($event, msg)"
           @touchstart="touchStart($event, msg)" @touchend="touchEnd">

        <div class="message-wrapper">
          <img v-if="msg.sender_id !== auth.user?.id"
               :src="avatarUrl(otherUser?.avatar)"
               class="message-avatar" @click="$router.push(`/profile/${otherUser?.id}`)" />

          <div class="message-bubble">
            <!-- Reply preview -->
            <div v-if="msg.reply_to" class="reply-preview" @click="scrollToMsg(msg.reply_to_id)">
              <div class="reply-preview-line"></div>
              <div>
                <div class="reply-preview-author">{{ msg.reply_to.sender?.username }}</div>
                <div class="reply-preview-text">{{ msg.reply_to.content?.slice(0,60) }}</div>
              </div>
            </div>

            <!-- Forwarded -->
            <div v-if="msg.is_forwarded" class="forwarded-label">
              <svg width="12" height="12" viewBox="0 0 24 24"><use href="#icon-forward"/></svg>
              Переслано{{ msg.show_forward_sender && msg.forwarded_from?.sender ? ` от ${msg.forwarded_from.sender.username}` : '' }}
            </div>

            <!-- Image -->
            <img v-if="msg.image_path" :src="`/static/uploads/${msg.image_path}`"
                 class="message-image" @click="openImage(`/static/uploads/${msg.image_path}`)" />

            <!-- File -->
            <a v-if="msg.file_path && !msg.image_path" :href="`/static/uploads/${msg.file_path}`"
               class="file-message" target="_blank">
              <span class="file-icon">{{ fileIcon(msg.file_name) }}</span>
              <div class="file-info">
                <div class="file-name">{{ msg.file_name }}</div>
                <div class="file-size">{{ formatSize(msg.file_size) }}</div>
              </div>
              <svg width="18" height="18" viewBox="0 0 24 24" style="color:var(--text-secondary)"><use href="#icon-download"/></svg>
            </a>

            <!-- Text -->
            <div v-if="msg.content && !msg.is_deleted" class="message-content">
              <p>{{ msg.content }}</p>
            </div>
            <div v-if="msg.is_deleted" class="message-content" style="color:var(--text-muted);font-style:italic">
              <p>Сообщение удалено</p>
            </div>

            <!-- Link preview -->
            <div v-if="msg.link_url && !msg.is_deleted" class="link-preview">
              <a :href="msg.link_url" target="_blank" class="link-preview-inner">
                <img v-if="msg.link_image" :src="msg.link_image" class="link-preview-img" />
                <div class="link-preview-text">
                  <div class="link-preview-title">{{ msg.link_title }}</div>
                  <div class="link-preview-desc">{{ msg.link_description }}</div>
                  <div class="link-preview-url">{{ msg.link_url }}</div>
                </div>
              </a>
            </div>

            <!-- Pinned -->
            <div v-if="msg.is_pinned" class="pinned-badge">
              <svg width="12" height="12" viewBox="0 0 24 24"><use href="#icon-pin"/></svg>
            </div>

            <div class="message-meta">
              <span v-if="msg.is_edited && !msg.is_deleted" style="font-size:10px;opacity:.7">изм.</span>
              <span>{{ formatTime(msg.timestamp) }}</span>
              <span v-if="msg.sender_id === auth.user?.id">
                <svg v-if="msg.is_read" width="14" height="14" viewBox="0 0 24 24" style="color:var(--accent)"><use href="#icon-checkmark-double"/></svg>
                <svg v-else width="14" height="14" viewBox="0 0 24 24" style="opacity:.6"><use href="#icon-check"/></svg>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Input -->
    <div class="message-input">
      <!-- File preview -->
      <div v-if="filePreview" class="file-preview">
        <div class="file-preview-info">
          <span class="file-icon">{{ fileIcon(filePreview.name) }}</span>
          <span>{{ filePreview.name }}</span>
        </div>
        <span class="file-preview-remove" @click="removeFile">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-close"/></svg>
        </span>
      </div>
      <div class="input-group">
        <label class="btn-icon" style="cursor:pointer" title="Прикрепить файл">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-attach"/></svg>
          <input type="file" style="display:none" @change="onFileChange" />
        </label>
        <input v-model="inputText" type="text" placeholder="Сообщение..."
               @keyup.enter="sendMessage" @input="onTyping" />
        <button class="btn-icon send-btn" @click="sendMessage" title="Отправить">
          <svg width="22" height="22" viewBox="0 0 24 24"><use href="#icon-send"/></svg>
        </button>
      </div>
    </div>

    <!-- Context menu -->
    <Teleport to="body">
      <div v-if="ctxMenu.show" class="context-menu"
           :style="{ top: ctxMenu.y + 'px', left: ctxMenu.x + 'px' }"
           @click.stop>
        <div class="context-menu-item" @click="replyToMsg(ctxMenu.msg)">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-reply"/></svg> Ответить
        </div>
        <div v-if="ctxMenu.msg?.sender_id === auth.user?.id" class="context-menu-item" @click="startEdit(ctxMenu.msg)">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-edit"/></svg> Редактировать
        </div>
        <div class="context-menu-item" @click="forwardMsg(ctxMenu.msg)">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-forward"/></svg> Переслать
        </div>
        <div class="context-menu-item" @click="copyMsg(ctxMenu.msg)">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-copy"/></svg> Копировать
        </div>
        <div class="context-menu-divider"></div>
        <div v-if="ctxMenu.msg?.sender_id === auth.user?.id" class="context-menu-item delete-item" @click="deleteMsg(ctxMenu.msg)">
          <svg width="18" height="18" viewBox="0 0 24 24"><use href="#icon-delete"/></svg> Удалить
        </div>
      </div>
    </Teleport>

    <!-- Image lightbox -->
    <Teleport to="body">
      <div v-if="lightboxSrc" class="modal-overlay" @click="lightboxSrc = null"
           style="background:rgba(0,0,0,0.95)">
        <img :src="lightboxSrc" style="max-width:90vw;max-height:90vh;border-radius:8px" />
      </div>
    </Teleport>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, nextTick, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useSocket } from '@/composables/useSocket'
import { useToast } from '@/composables/useToast'
import api from '@/composables/api'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const { connect, getSocket } = useSocket()
const { showToast } = useToast()

const chatId = computed(() => route.params.id)
const otherUser = ref(null)
const messages = ref([])
const inputText = ref('')
const msgsEl = ref(null)
const loading = ref(true)
const loadingMore = ref(false)
const page = ref(1)
const hasMore = ref(true)
const filePreview = ref(null)
const fileInput = ref(null)
const replyTo = ref(null)
const editMsg = ref(null)
const showSearch = ref(false)
const searchMsg = ref('')
const lightboxSrc = ref(null)

const ctxMenu = ref({ show: false, x: 0, y: 0, msg: null })
let touchTimer = null

const filteredMessages = computed(() => {
  if (!searchMsg.value) return messages.value
  const q = searchMsg.value.toLowerCase()
  return messages.value.filter(m => m.content?.toLowerCase().includes(q))
})

function avatarUrl(p) { return p ? `/static/uploads/${p}` : '/static/uploads/avatars/default.png' }
function onImgError(e) { e.target.src = '/static/uploads/avatars/default.png' }
function formatTime(ts) {
  if (!ts) return ''
  const d = new Date(ts)
  return d.toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' })
}
function formatSize(b) {
  if (!b) return ''
  if (b < 1024) return b + ' B'
  if (b < 1048576) return (b/1024).toFixed(1) + ' KB'
  return (b/1048576).toFixed(1) + ' MB'
}
function fileIcon(name) {
  const ext = name?.split('.').pop()?.toLowerCase() || ''
  const m = { jpg:'🖼️',jpeg:'🖼️',png:'🖼️',gif:'🎨',webp:'🖼️',
    mp4:'🎬',avi:'🎬',mov:'🎬',mkv:'🎬',
    mp3:'🎵',wav:'🎵',ogg:'🎵',flac:'🎵',
    pdf:'📄',doc:'📝',docx:'📝',txt:'📄',
    xls:'📊',xlsx:'📊',csv:'📊',ppt:'📊',pptx:'📊',
    zip:'📦',rar:'📦','7z':'📦',tar:'📦',
    exe:'⚙️',apk:'📱' }
  return m[ext] || '📎'
}

function openImage(src) { lightboxSrc.value = src }
function scrollToBottom(smooth = false) {
  nextTick(() => {
    if (msgsEl.value) msgsEl.value.scrollTop = msgsEl.value.scrollHeight
  })
}
function scrollToMsg(id) {
  const el = document.getElementById(`msg-${id}`)
  if (el) { el.scrollIntoView({ behavior: 'smooth' }); el.style.outline = '2px solid var(--accent)'; setTimeout(() => el.style.outline = '', 1500) }
}

async function load(lastId = 0) {
  try {
    const res = await api.getChatInfo(chatId.value)
    const data = res.data
    otherUser.value = data.chat?.other_user
    if (lastId === 0) {
      messages.value = data.messages || []
      scrollToBottom()
    } else {
      // load older messages
      const older = await api.getChatMessages(chatId.value, lastId)
      messages.value = [...(older.data || []), ...messages.value]
    }
    hasMore.value = (data.messages?.length || 0) >= 50
  } finally {
    loading.value = false
  }
}

function onScroll() {
  if (msgsEl.value?.scrollTop < 50 && hasMore.value && !loadingMore.value) {
    loadingMore.value = true
    const firstId = messages.value[0]?.id || 0
    const prevHeight = msgsEl.value.scrollHeight
    api.getChatMessages(chatId.value, firstId).then(res => {
      const older = res.data || []
      if (older.length === 0) { hasMore.value = false }
      messages.value = [...older, ...messages.value]
      nextTick(() => {
        msgsEl.value.scrollTop = msgsEl.value.scrollHeight - prevHeight
        loadingMore.value = false
      })
    }).catch(() => { loadingMore.value = false })
  }
}

function onTyping() {
  const socket = getSocket()
  if (socket) socket.emit('typing', { chat_id: chatId.value })
}

async function sendMessage() {
  const text = inputText.value.trim()
  if (!text && !filePreview.value) return

  try {
    if (editMsg.value) {
      await api.editMessage(editMsg.value.id, { content: text })
      const idx = messages.value.findIndex(m => m.id === editMsg.value.id)
      if (idx >= 0) messages.value[idx] = { ...messages.value[idx], content: text, is_edited: true }
      editMsg.value = null
    } else {
      const formData = new FormData()
      formData.append('chat_id', chatId.value)
      if (text) formData.append('content', text)
      if (replyTo.value) formData.append('reply_to_id', replyTo.value.id)
      if (filePreview.value) formData.append('file', filePreview.value.raw)
      const res = await api.sendMessage(formData)
      // socket will handle displaying, but add locally too
      const newMsg = {
        id: res.data.message_id,
        content: res.data.content,
        sender_id: auth.user?.id,
        sender_name: auth.user?.username,
        sender_avatar: auth.user?.avatar,
        image_path: res.data.image_path,
        file_path: res.data.file_path,
        file_name: res.data.file_name,
        file_size: res.data.file_size,
        timestamp: res.data.timestamp,
        is_read: false, is_edited: false, is_forwarded: false,
        link_url: res.data.link_url, link_title: res.data.link_title,
        link_description: res.data.link_description, link_image: res.data.link_image,
        reply_to: replyTo.value ? { id: replyTo.value.id, content: replyTo.value.content, sender: replyTo.value.sender } : null,
      }
      if (!messages.value.find(m => m.id === newMsg.id)) {
        messages.value.push(newMsg)
      }
      scrollToBottom(true)
    }
    inputText.value = ''
    filePreview.value = null
    replyTo.value = null
  } catch (e) {
    showToast(e.response?.data?.error || 'Ошибка отправки')
  }
}

function onFileChange(e) {
  const f = e.target.files[0]
  if (f) filePreview.value = { name: f.name, raw: f }
}
function removeFile() { filePreview.value = null }

function replyToMsg(msg) { replyTo.value = msg; editMsg.value = null; closeCtx() }
function startEdit(msg) { editMsg.value = msg; inputText.value = msg.content; replyTo.value = null; closeCtx() }
function clearReply() { replyTo.value = null; editMsg.value = null; inputText.value = '' }

async function deleteMsg(msg) {
  closeCtx()
  if (!confirm('Удалить сообщение?')) return
  try {
    await api.deleteMessage(msg.id)
    const idx = messages.value.findIndex(m => m.id === msg.id)
    if (idx >= 0) messages.value[idx] = { ...messages.value[idx], is_deleted: true }
  } catch { showToast('Ошибка') }
}

async function copyMsg(msg) {
  closeCtx()
  await navigator.clipboard.writeText(msg.content || '')
  showToast('Скопировано')
}

function forwardMsg(msg) { closeCtx(); showToast('Функция пересылки — скоро') }

function showCtxMenu(e, msg) {
  ctxMenu.value = { show: true, x: Math.min(e.clientX, window.innerWidth - 220), y: Math.min(e.clientY, window.innerHeight - 200), msg }
}
function closeCtx() { ctxMenu.value.show = false }

function touchStart(e, msg) {
  touchTimer = setTimeout(() => showCtxMenu({ clientX: 100, clientY: 300 }, msg), 500)
}
function touchEnd() { clearTimeout(touchTimer) }

onMounted(async () => {
  await load()
  const socket = connect()
  socket.emit('join_chat', { chat_id: chatId.value })
  socket.on('new_message', (msg) => {
    if (msg.chat_id == chatId.value) {
      messages.value.push(msg)
      scrollToBottom(true)
    }
  })
  socket.on('message_edited', (data) => {
    const idx = messages.value.findIndex(m => m.id === data.message_id)
    if (idx >= 0) messages.value[idx] = { ...messages.value[idx], content: data.content, is_edited: true }
  })
  socket.on('message_deleted', (data) => {
    const idx = messages.value.findIndex(m => m.id === data.message_id)
    if (idx >= 0) messages.value[idx] = { ...messages.value[idx], is_deleted: true }
  })
  document.addEventListener('click', closeCtx)
})

onUnmounted(() => {
  document.removeEventListener('click', closeCtx)
  const socket = getSocket()
  if (socket) socket.emit('leave_chat', { chat_id: chatId.value })
})
</script>

<style scoped>
.chat-container {
  display: flex; flex-direction: column; height: 100dvh;
  background: var(--bg-primary); overflow: hidden;
  position: fixed; inset: 0;
}
.chat-header {
  padding: 12px 16px; background: var(--bg-secondary);
  display: flex; justify-content: space-between; align-items: center;
  border-bottom: 1px solid var(--border); flex-shrink: 0;
}
.chat-user-info { display: flex; align-items: center; gap: 10px; }
.chat-avatar-link { text-decoration: none; }
.chat-avatar-img { width: 42px; height: 42px; border-radius: 50%; object-fit: cover; border: 2px solid var(--accent); }
.chat-user-details h2 { font-size: 17px; font-weight: 600; margin-bottom: 2px; }
.chat-user-details p { font-size: 13px; color: var(--text-secondary); display: flex; align-items: center; gap: 5px; }
.header-actions { display: flex; gap: 8px; }

.msg-search-bar {
  padding: 8px 16px; background: var(--bg-tertiary);
  display: flex; align-items: center; gap: 10px; flex-shrink: 0;
  border-bottom: 1px solid var(--border);
}
.msg-search-bar input { background: transparent; border: none; color: var(--text-primary); width: 100%; font-size: 14px; outline: none; }

.reply-bar {
  padding: 8px 16px; background: var(--bg-secondary);
  border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 10px; flex-shrink: 0;
}
.reply-bar-inner { display: flex; align-items: center; gap: 10px; flex: 1; }
.reply-line { width: 3px; height: 36px; background: var(--accent); border-radius: 2px; flex-shrink: 0; }
.reply-label { font-size: 12px; color: var(--accent); font-weight: 600; }
.reply-text { font-size: 13px; color: var(--text-secondary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 250px; }
.reply-close { background: none; border: none; color: var(--text-muted); cursor: pointer; display: flex; align-items: center; }

.messages-container {
  flex: 1; min-height: 0; padding: 16px; overflow-y: auto;
  background: #0e1c26;
  background-image: radial-gradient(circle at 10% 20%, rgba(0,168,132,.03) 0%, transparent 20%);
  display: flex; flex-direction: column; gap: 6px;
}

.message { max-width: 65%; animation: messageAppear 0.2s ease-out; }
.message.sent { align-self: flex-end; }
.message.received { align-self: flex-start; }

.message-wrapper { display: flex; align-items: flex-end; gap: 8px; }
.message.sent .message-wrapper { flex-direction: row-reverse; }

.message-avatar { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; cursor: pointer; flex-shrink: 0; }

.message-bubble {
  padding: 10px 14px; border-radius: 18px; position: relative;
  word-wrap: break-word; overflow-wrap: break-word;
}
.message.sent .message-bubble { background: var(--sent-message); border-bottom-right-radius: 4px; }
.message.received .message-bubble { background: var(--received-message); border-bottom-left-radius: 4px; }

.message-content { margin-bottom: 4px; }
.message-content p { margin: 0; white-space: pre-wrap; line-height: 1.5; }

.message-image { max-width: 280px; max-height: 280px; border-radius: 12px; cursor: pointer; display: block; margin-bottom: 6px; }

.file-message {
  display: flex; align-items: center; gap: 10px; padding: 10px;
  background: rgba(255,255,255,.08); border-radius: 12px;
  text-decoration: none; color: var(--text-primary); min-width: 220px;
}
.file-icon { font-size: 28px; }
.file-info { flex: 1; min-width: 0; }
.file-name { font-weight: 600; font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.file-size { font-size: 11px; color: var(--text-muted); }

.message-meta { display: flex; justify-content: flex-end; align-items: center; gap: 4px; font-size: 11px; margin-top: 4px; }
.message.sent .message-meta { color: rgba(255,255,255,.65); }
.message.received .message-meta { color: var(--text-muted); }

.forwarded-label { font-size: 12px; color: var(--text-secondary); margin-bottom: 6px; display: flex; align-items: center; gap: 4px; font-style: italic; }

.reply-preview {
  display: flex; gap: 8px; margin-bottom: 8px; cursor: pointer;
  background: rgba(255,255,255,.05); border-radius: 8px; padding: 6px 8px;
}
.reply-preview-line { width: 3px; background: var(--accent); border-radius: 2px; flex-shrink: 0; }
.reply-preview-author { font-size: 12px; color: var(--accent); font-weight: 600; }
.reply-preview-text { font-size: 12px; color: var(--text-secondary); }

.link-preview { margin-top: 8px; }
.link-preview-inner {
  display: flex; gap: 10px; text-decoration: none;
  background: rgba(255,255,255,.05); border-radius: 10px; overflow: hidden;
  border-left: 3px solid var(--accent);
}
.link-preview-img { width: 80px; height: 80px; object-fit: cover; flex-shrink: 0; }
.link-preview-text { padding: 8px; flex: 1; }
.link-preview-title { font-weight: 600; font-size: 13px; color: var(--text-primary); margin-bottom: 4px; }
.link-preview-desc { font-size: 12px; color: var(--text-secondary); margin-bottom: 4px; }
.link-preview-url { font-size: 11px; color: var(--accent); }

.pinned-badge { position: absolute; top: 4px; right: 4px; color: var(--accent); }

.message-input {
  padding: 16px; background: var(--bg-secondary);
  border-top: 1px solid var(--border); flex-shrink: 0;
}
.file-preview {
  margin-bottom: 10px; padding: 10px 14px; background: var(--bg-tertiary);
  border-radius: var(--radius-md); display: flex; justify-content: space-between; align-items: center;
}
.file-preview-info { display: flex; align-items: center; gap: 10px; font-size: 14px; }
.file-preview-remove { color: var(--danger); cursor: pointer; display: flex; align-items: center; }

.input-group {
  display: flex; gap: 10px; align-items: center;
  background: var(--bg-tertiary); border-radius: 24px; padding: 6px 10px;
}
.input-group input {
  flex: 1; padding: 10px; background: transparent; border: none;
  color: var(--text-primary); font-size: 15px; outline: none;
}
.input-group input::placeholder { color: var(--text-muted); }
.send-btn { background: var(--accent) !important; color: white !important; }
.send-btn:hover { background: var(--accent-hover) !important; }

.slide-down-enter-active, .slide-down-leave-active { transition: all 0.2s ease; }
.slide-down-enter-from, .slide-down-leave-to { opacity: 0; transform: translateY(-10px); }

@media (max-width: 768px) {
  .message { max-width: 85%; }
}
</style>
