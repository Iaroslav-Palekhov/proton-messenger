# Papirus Vue — Фронтенд на Vue 3

Полный Vue 3 фронтенд для мессенджера Papirus, повторяющий дизайн и функциональность оригинала.

## Технологии

- **Vue 3** (Composition API, `<script setup>`)
- **Vue Router 4** — навигация между страницами
- **Pinia** — управление состоянием (авторизация)
- **Socket.IO Client** — реалтайм сообщения
- **Axios** — HTTP запросы к API
- **Vite** — сборщик

## Установка и запуск

```bash
# Установить зависимости
npm install

# Запустить dev-сервер (порт 5173)
npm run dev

# Сборка для продакшена
npm run build
```

## Структура проекта

```
src/
├── assets/
│   └── main.css          # Глобальные стили (CSS переменные, компоненты)
├── components/
│   └── SvgSprite.vue     # SVG иконки (все иконки из оригинала)
├── composables/
│   ├── api.js            # Все API запросы
│   ├── useSocket.js      # Socket.IO singleton
│   └── useToast.js       # Toast уведомления
├── router/
│   └── index.js          # Vue Router с guard'ами авторизации
├── stores/
│   └── auth.js           # Pinia store для пользователя
└── views/
    ├── LoginView.vue         # /login
    ├── RegisterView.vue      # /register
    ├── ForgotPasswordView.vue # /forgot-password
    ├── ResetPasswordView.vue  # /reset-password/:token
    ├── ChatsView.vue         # /chats (список чатов + drawer меню)
    ├── ChatView.vue          # /chat/:id (личный чат)
    ├── GroupChatView.vue     # /group/:id (групповой чат)
    ├── GroupMembersView.vue  # /group/:id/members
    ├── ProfileView.vue       # /profile/:id
    ├── EditProfileView.vue   # /edit-profile
    ├── SecurityView.vue      # /security
    ├── PasswordView.vue      # /security/password
    ├── DevicesView.vue       # /security/devices
    └── BlacklistView.vue     # /security/blacklist
```

## Настройка прокси

Vite настроен проксировать `/api`, `/static`, `/socket.io` на `http://localhost:2200` (Flask бекенд).

Если бекенд на другом порту — измените `vite.config.js`:

```js
proxy: {
  '/api': { target: 'http://localhost:ВАШ_ПОРТ', ... }
}
```

## Что реализовано

- ✅ Авторизация (вход, регистрация, сброс пароля)
- ✅ Список чатов с поиском и drawer-меню
- ✅ Личный чат: отправка, редактирование, удаление, ответ, пересылка
- ✅ Групповой чат: все функции + управление группой
- ✅ Отправка файлов и изображений
- ✅ Контекстное меню (правый клик / долгое нажатие)
- ✅ Реалтайм обновления через Socket.IO
- ✅ Профиль пользователя, редактирование, блокировка
- ✅ Безопасность: смена пароля, сессии/устройства, чёрный список
- ✅ Оригинальный тёмный дизайн (#0b141a)
- ✅ Все SVG иконки из оригинала
- ✅ Анимации, toast-уведомления
- ✅ Мобильная адаптация
